var mapsNight			 = new Array( new Map(1000, "mapPreviews/1000.png", "Nachtrennen", 5, true),
	                              new Map(1001, "mapPreviews/1001.png", "Nachtkurven", 4, true),
	                              new Map(1002, "mapPreviews/1002.png", "Kurven in der Nacht", 4, true),
	                              new Map(1003, "mapPreviews/1003.png", "Meteoritenfeld", 6, true),
	                              new Map(1004, "mapPreviews/1004.png", "The Maze", 14, true)
                                );