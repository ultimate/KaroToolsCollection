var specialPlayers = new Array(	new Player(1411, "ultimate"),
																new Player(1413, "tepetz"),
																new Player(1478, "outbreak"),
																new Player(1465, "wombat"),
																new Player(1476, "Mr.X"),
																new Player(1482, "darf ich mal bitte d"),
																new Player(1484, "ais"),
																new Player(1471, "peschke.holger")
					
					new Player(1659, "Tastaturkrieger"),
											                                );