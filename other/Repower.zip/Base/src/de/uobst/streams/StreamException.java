package de.uobst.streams;

@SuppressWarnings("serial")
public class StreamException extends RuntimeException {
    public StreamException(Exception ex) {
        super(ex);
    }

    @SuppressWarnings("unchecked")
    public <T extends Exception> void throwIf(Class<T> exClass) throws T {
        if (exClass.isInstance(getCause())) {
            throw (T)getCause();
        }
    }
}
