package de.uobst.streams;

public interface RunnableWithException {
    public void run() throws Exception;

}
