package de.uobst.streams;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class ExceptionWrapper {
    public interface ConsumerWithException<T> {
        void consume(T t) throws Exception;
    }

    public static <P, R> Function<P, R> wrap(FunctionWithException<P, R> f) {
        return p -> {
            try {
                return f.apply(p);
            } catch (Exception ex) {
                throw new StreamException(ex);
            }
        };
    }

    public static <T> Consumer<T> consumer(ConsumerWithException<T> c) {
        return p -> {
            try {
                c.consume(p);
            } catch (Exception ex) {
                throw new StreamException(ex);
            }
        };
    }

    public static <T> Predicate<T> predicate(FunctionWithException<T, Boolean> f) {
        return t -> {
            try {
                return f.apply(t);
            } catch (Exception ex) {
                throw new StreamException(ex);
            }
        };
    }
}
