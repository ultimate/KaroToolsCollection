package de.uobst.streams;

public interface FunctionWithException<P, R> {
    R apply(P p) throws Exception;
}
