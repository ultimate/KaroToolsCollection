package de.uobst.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class StreamPump {
    public static void pump(InputStream from, OutputStream to) throws IOException {
        byte[] buffer = new byte[256];
        int n = 0;
        while((n = from.read(buffer)) != -1) {
            to.write(buffer,  0,  n);
        }
    }
}
