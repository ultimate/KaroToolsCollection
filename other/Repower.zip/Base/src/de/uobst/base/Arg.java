package de.uobst.base;

public class Arg {
    public static <T> T notNull(T arg, String argname) {
        if (arg == null) {
            throw new IllegalArgumentException(argname + " is null");
        }
        return arg;
    }

    public static void check(boolean b,  String msg) {
        if (!b) {
            throw new IllegalArgumentException(msg);
        }
    }

    public static void checkRange(int value, int fromInclusive, int toInclusive) {
        check(Range.between(value,  fromInclusive,  toInclusive), String.format("Value %d of of range [%d, %d]", value, fromInclusive, toInclusive));
    }

}
