package de.uobst.base;

public class Objects {
    public static <T> T firstNonNull(T v1, T v2) {
        return v1 == null ? v2 : v1;
    }
}
