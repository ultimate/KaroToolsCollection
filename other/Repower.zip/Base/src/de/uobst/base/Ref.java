package de.uobst.base;

import org.eclipse.jdt.annotation.Nullable;

public class Ref<@Nullable T> {

    private T value;

    public Ref(T v) {
        this.value = v;
    }

    public T get() {
        return value;
    }

    public void set(T v) {
        this.value = v;
    }

}
