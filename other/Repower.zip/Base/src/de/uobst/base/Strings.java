package de.uobst.base;

public class Strings {
	public static String capitalize(String s) {
		if (isEmpty(s)) {
			return s;
		}
		return Character.toUpperCase(s.charAt(0)) + s.substring(1);
	}

	public static boolean isEmpty(String s) {
	    return s == null || s.isEmpty();
	}

    public static int compare(String s1, String s2, boolean nullFirst) {
        if (isEmpty(s1) && isEmpty(s2)) {
            return 0;
        }

        if (isEmpty(s1)) {
            return nullFirst? -1 : 1;
        }

        if (isEmpty(s2)) {
            return nullFirst? 1 : -1;
        }

        return s1.compareTo(s2);
    }

    public static char getLastChar(String s) {
        return s.charAt(s.length() - 1);
    }
}
