package de.uobst.base.collection;

import java.io.Serializable;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;


public class RingBuffer<T> extends AbstractCollection<T> implements Serializable {

    private static final long serialVersionUID = 8460393156741739877L;

    private final List<T> list;
    private int ptr;
    private final int capacity;


    public RingBuffer(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("size <= 0");
        }
        list = new ArrayList<>(this.capacity = capacity);
    }

    @Override
    public boolean add(T t)  {
        if (list.size() < capacity) {
            list.add(t);
        } else {
            list.set(ptr, t);
            ptr = (ptr + 1) % capacity;
        }
        return true;
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            int n = 0;
            final int p = ptr;
            final int s = size();

            @Override
            public boolean hasNext() {
                return n < s;
            }

            @Override
            public T next() {
                if (p != ptr || s != size()) {
                    throw new ConcurrentModificationException();
                }
                if (!hasNext()) {
                    throw new NoSuchElementException();
                } else {
                    return list.get((p + n++) % s);
                }
            }
        };
    }

    @Override
    public int size() {
        return list.size();
    }

    @Override
    public boolean remove(Object o) {
       throw new UnsupportedOperationException();
    }

    @Override
    public void clear() {
        list.clear();
        ptr = 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj != null && obj.getClass() == getClass()) {
            RingBuffer<?> rb = (RingBuffer<?>)obj;
            if (size() == rb.size()) {
                for (Iterator<?> i1 = iterator(), i2 = rb.iterator(); i1.hasNext(); ) {
                    Object o1 = i1.next();
                    Object o2 = i2.next();
                    if (o1 == o2) {
                        continue;
                    }

                    if (o1 == null || !o1.equals(o2)) {
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }

    @Override
    public int hashCode() {
        int h = 1;

        for (Object obj : this) {
            h = 31 * h + (obj == null ? 0 : obj.hashCode());
        }

        return h;
    }

    public T first() {
        if (isEmpty()) {
            throw new NoSuchElementException("ringbuffer is empty");
        }

        return list.get(ptr);
    }

    public T last() {
        if (isEmpty()) {
            throw new NoSuchElementException("ringbuffer is empty");
        }
        return list.get(list.size() < capacity ? list.size() - 1 : (ptr + capacity - 1) % capacity);
    }

}
