package de.uobst.base.collection;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class IteratorChain<T> implements Iterator<T> {
    private Iterator<? extends Iterator<? extends T>> iiter;
    private Iterator<? extends T> currentIter;

    /** Der Iteratoir, der das letzte Element geliefert hat
     */
    private Iterator<?> lastElementIterator = null;

    public IteratorChain(Collection<? extends Iterator<? extends T>> iters) {
        this(iters.iterator());
    }

    public IteratorChain(Iterator<? extends Iterator<? extends T>> iters) {
        this.iiter = iters;
        nextIter();
    }

    @SafeVarargs
    public IteratorChain(Iterator<? extends T> ... iters) {
        this(Arrays.asList(iters).iterator());
    }

    private void nextIter() {
        while(iiter.hasNext()) {
            currentIter = iiter.next();
            if (currentIter.hasNext()) {
                return;
            }
        }
        currentIter = null;
    }

    @Override
    public boolean hasNext() {
        return currentIter != null;
    }

    @Override
    public T next() {
        if (currentIter != null) {
            T ret = currentIter.next();
            lastElementIterator = currentIter;
            if (!currentIter.hasNext()) {
                nextIter();
            }
            return ret;
        } else {
            throw new NoSuchElementException();
        }
    }

    @Override
    public void remove() {
        if (lastElementIterator != null) {
            lastElementIterator.remove();
            lastElementIterator = null;
        } else {
            throw new NoSuchElementException();
        }
    }

    /*
public static void main(String[] args) {
    List<Integer> l1 = new ArrayList<>(Arrays.asList(1, 2, 3));
    List<Integer> l11 = new ArrayList<>(Arrays.asList(4));

    List<Integer> l2 = new ArrayList<>(Arrays.asList(5, 6, 7));
    int n = 0;
    for (Iterator<Integer> i1 = new IteratorChain<>(Collections.emptyIterator(), l1.iterator(), l11.iterator(), Collections.emptyIterator(), l2.iterator(), Collections.emptyIterator()); i1.hasNext(); ) {
        if (i1.next() != n + 1) {
            System.out.println(n + 1);
        }
        i1.remove();
        n++;
    }
    System.out.println(n);
    System.out.println(l1.size() + " " + l2.size() + " " + l11.size());
}
*/
    }
