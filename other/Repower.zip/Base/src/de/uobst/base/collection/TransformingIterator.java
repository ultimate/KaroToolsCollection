/*
 * This class is part of the project SIRIUS
 *
 * Author: BREDEX GmbH
 *
 * Copyright Skantours International, Isenbuettel, Germany
 */
package de.uobst.base.collection;

import java.util.Iterator;
import java.util.function.Function;

/** Iterator the transforms the objects providet by the delegate iterator using the given function
 * @author ulli
 *
 */
public class TransformingIterator<S, T> implements Iterator<T> {

    private Iterator<S> sourceIter;
    private Function<S, T> transformer;

    public TransformingIterator(Iterator<S> sourceIter,
        Function<S, T> transformer) {
        this.sourceIter = sourceIter;
        this.transformer = transformer;
    }

    @Override
    public boolean hasNext() {
        return sourceIter.hasNext();
    }

    @Override
    public T next() {
        return transformer.apply(sourceIter.next());
    }

    @Override
    public void remove() {
        sourceIter.remove();
    }
}
