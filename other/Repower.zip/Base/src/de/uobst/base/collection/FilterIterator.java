package de.uobst.base.collection;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.function.Predicate;

import org.eclipse.jdt.annotation.Nullable;

public final class FilterIterator<@Nullable T> implements Iterator<T>{
    private final Iterator<? extends T> delegate;
    private final Predicate<? super T> filter;
    @Nullable private T next;
    private boolean hasNext = true;


    public FilterIterator(Iterator<? extends T> delegate, Predicate<? super T> filter) {
        this.delegate = delegate;
        this.filter = filter;
        _next();
    }

    private void _next() {
        do {
            if (!delegate.hasNext()) {
                hasNext = false;
                next = null;
                return;
            }

            next = delegate.next();
        } while (!filter.test(next));
    }

    @Override
    public T next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        var n = next;
        _next();
        return n;
    }

    @Override
    public boolean hasNext() {
        return hasNext;
    }
}
