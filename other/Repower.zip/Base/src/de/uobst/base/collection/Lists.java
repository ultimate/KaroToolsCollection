package de.uobst.base.collection;

import java.util.List;
import java.util.Random;

public class Lists {

    public static <T> T last(List<? extends T> list) {
    	return list.get(list.size() - 1);
    }

    public static <V> V get(List<? extends V> list, int idx) {
        if (idx >= 0) {
            return list.get(idx);
        } else {
            return list.get(list.size() + idx);
        }
    }

    public static <T> T getRandom(List<T> l, Random r) {
        return l.get(r.nextInt(l.size()));
    }

    public static <T> T removeRandom(List<T> l, Random r) {
        return l.remove(r.nextInt(l.size()));
    }

    public static int randomIndex(List<?> l, Random r) {
        return r.nextInt(l.size());
    }
}
