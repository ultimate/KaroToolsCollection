package de.uobst.base.collection;

import java.util.AbstractList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/** Immutable List of Lists, that provides simple List interface.
 * It is possible to construct a list of lists without copying all lists into one. The ListList
 * is backed by the underlying lists, so it is possible to modify a Listlist by modifying the
 * underlying lists
 * @author ulli1
 *
 * @param <T>
 */
public final class ListList<T> extends AbstractList<T> {

    private List<List<? extends T>> listlist;

    @SafeVarargs
    public ListList(List<? extends T> ... lists) {
        listlist = new LinkedList<>();
        for (var l : lists) {
            listlist.add(l);
        }
    }

    public ListList(Collection<? extends List<? extends T>> lists) {
        listlist = new LinkedList<>();
        listlist.addAll(lists);
    }

    public void addList(List<? extends T> list) {
        listlist.add(list);
    }

    @Override
    public int size() {
        return listlist.stream().mapToInt(l -> l.size()).sum();
    }

    @Override
    public void clear() {
        listlist.clear();
    }

    @Override
    public T get(int index) {
        int n = index;
        for (var l : listlist) {
            if (n >= l.size()) {
                n -= l.size();
            } else {
                return l.get(n);
            }
        }
        throw new IndexOutOfBoundsException("index: " + index + ", size: " + size());
    }


    /** Returns a readonly iterator for this ListList (i.e. the remove method is not implemented)
     */
    @Override
    public Iterator<T> iterator() {
        return new IteratorChain<>(new TransformingIterator<>(listlist.iterator(), list -> list.iterator()));
    }

    /*
    private static void check(List<Integer> ... lists) {
        var underTest = new ListList<>(lists);
        var checker = new ArrayList<Integer>();
        for (var l : lists) {
            checker.addAll(l);
        }
        if (!underTest.equals(checker)
            || !checker.equals(underTest)) {
            throw new IllegalStateException();
        }
    }

    public static void main(String[] args) {
        check(List.of(1, 2), List.of(3, 4));
        check(List.of(1, 2), Collections.emptyList(), List.of(3, 4));
        check(List.of(1, 2), List.of(3, 4), new ArrayList<>());
        check(new ArrayList<>(), List.of(1, 2), List.of(3, 4), new ArrayList<>());
        check();
        check(new ArrayList<Integer>());
        check(List.of(1));
        check(List.of(1, 2), new ListList<>(List.of(3, 4), new ListList<>(List.of(5, 6))), new ListList<>());
        System.out.println("ok");

    }
    */
}
