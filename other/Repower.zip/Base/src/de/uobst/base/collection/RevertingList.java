package de.uobst.base.collection;

import java.util.AbstractList;
import java.util.List;

/** List-Decorator, der die Zugrundeliegende Liste in der Reihenfolge umkehrt
 *
 * @param <E>
 */
public class RevertingList<E> extends AbstractList<E> {
    private final List<E> delegate;

    public RevertingList(List<E> delegate) {
        this.delegate = delegate;
    }

    @Override
    public E get(int location) {
        return delegate.get(delegate.size() - 1 - location);
    }

    @Override
    public int size() {
        return delegate.size();
    }

    @Override
    public void add(int location, E object) {
        delegate.add(delegate.size() - location, object);
    }

    @Override
    public E remove(int location) {
        return delegate.remove(size() - 1 - location);
    }

    @Override
    public E set(int location, E object) {
        return delegate.set(size() - 1 - location, object);
    }

    @Override
    public int indexOf(Object object) {
        int idx = delegate.lastIndexOf(object);
        if (idx != -1) {
            idx = size() - 1 - idx;
        }
        return idx;
    }

    @Override
    public int lastIndexOf(Object o) {
        int idx = delegate.indexOf(o);
        if (idx != -1) {
            idx = size() - 1 - idx;
        }
        return idx;
    }

}
