package de.uobst.base.collection;

import java.util.Collection;
import java.util.List;

public class CollectionUtils {

    public static boolean isEmpty(Collection<?> c) {
        return c == null || c.isEmpty();
    }

    public static <T> T first(Collection<? extends T> coll) {
        return coll.iterator().next();
    }

    public static <T> T last(List<? extends T> l) {
        return l.get(l.size() - 1);
    }

}
