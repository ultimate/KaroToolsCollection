package de.uobst.base;


import java.io.Serializable;
import java.util.Random;


public class Range implements Serializable{
    private static final long serialVersionUID = -2956690226681908840L;

    /** @noinspection WeakerAccess*/
    public static final int LB_NOT_SET = Integer.MIN_VALUE;
    /** @noinspection WeakerAccess*/
    public static final int UB_NOT_SET = Integer.MAX_VALUE;
    /** @noinspection WeakerAccess*/
    public static final Range UNLIMITED = new Range();
    public static final Range POSITIVE_WITHOUT_ZERO = new Range(1, UB_NOT_SET);
    public static final Range POSITIVE_INCLUDING_ZERO = new Range(0, UB_NOT_SET);


    // Inclusive
    private final int lb;
    // Inclusive
    private final int ub;

    /** Parses an Integer string
     *
     * @param ptxt The String representing the integer
     * @param def The default value, if lenient = true, unused if lenient = false
     * @param lenient if true, the default value is returned if the string does not represent an integer
     *                if false: a NumberFormatException is throwsn if the string does not represent n integer
     * @return The integer value
     */
    private static int parse(String ptxt, int def, boolean lenient) {
        if (ptxt == null) {
            return  def;
        }
        String txt = ptxt.trim();
        if (txt.length() == 0) {
            return def;
        }
        try {
            return Integer.parseInt(txt);
        } catch (NumberFormatException ex) {
           if (lenient) {
               return def;
           } else {
               throw ex;
           }
        }
    }

    /**
     *  Returns true if px is i n range [start, end] (inclusive)
     * @return true/false
     */
    public static boolean between(int px, int start, int end) {
        return end > start ? px >= start && px <= end : px <= start && px >= end;
    }

    public static int correct(int px, int start, int end) {
        return Math.min(Math.max(px,  Math.min(start, end)), Math.max(start,  end));
    }

    public Range() {
        this(LB_NOT_SET, UB_NOT_SET);
    }

    public Range(String text) {
        this(text, true);
    }

    /** Parst einen Bereich. Der Text hat die Form "von-bis"
     * von oder bis oder beides kann weggelassen werden.
     *
     * @param text Der zu parsende Text
     * @param lenient true: Falls von und/oder bis keine g�ltigen zahlen sind,
     *                ist der Bereich naco unten bz. oben offen.
     *        lenient false: von und bis m�sse  entweder leer oder g�ltige Zahlen sein
     * @throws NumberFormatException falls lenient = false und von bzw. bis sind keine g�ltigen Zahlen
     */
    public Range(String text, boolean lenient) throws NumberFormatException {
        int idx = text.indexOf('-');
        if (idx == -1) {
            lb = parse(text, LB_NOT_SET, lenient);
            ub = parse(text, UB_NOT_SET, lenient);
        } else {
            lb = parse(text.substring(0, idx), LB_NOT_SET, lenient);
            ub = parse(text.substring(idx + 1), UB_NOT_SET, lenient);
        }
    }

    public Range(int lb, int ub) {
        this.lb = lb;
        this.ub = ub;
    }

    public boolean contains(int n) {
        return between(n, lb, ub);
    }

    public boolean contains(Range r) {
        return contains(r.getLb()) && contains(r.getUb());
    }

    public int getLb() {
        return lb;
    }

    public int getUb() {
        return ub;
    }

    @Override
    public String toString() {
        if (isUnlimited()) {
            return "";
        }

        if (lb == ub && hasLb() ) {
            return String.valueOf(lb);
        }

        StringBuilder text = new StringBuilder();
        if (hasLb()) {
            text.append(lb);
        }
        text.append("-");
        if (hasUb()) {
            text.append(ub);
        }

        return text.toString();
    }

    public boolean isUnlimited() {
        return !hasLb() && !hasUb();
    }

    public int getRandom(Random r, int minlb, int maxUB, int def) {
        if (isUnlimited()) {
            return def;
        }

        if (lb == ub) {
            return lb;
        }

        int l = Math.max(lb,  minlb);
        int u = Math.min(ub, maxUB);

        return r.nextInt(u - l) + l;
    }

    public Range unite(Range other) {
        return new Range(Math.min(lb, other.getLb()), Math.max(ub, other.getUb()));
    }

    public boolean hasLb() {
        return lb != LB_NOT_SET;
    }
    public boolean hasUb() {
        return ub != UB_NOT_SET;
    }


}
