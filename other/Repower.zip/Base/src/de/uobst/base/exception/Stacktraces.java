package de.uobst.base.exception;

import java.io.PrintWriter;
import java.io.StringWriter;

public class Stacktraces {
    public static  String getStacktrace(Throwable t) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        t.printStackTrace(pw);
        pw.flush();
        pw.close();
        return sw.toString();
    }


}
