package de.uobst.reader;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.UnsupportedCharsetException;
import java.util.Objects;

import org.eclipse.jdt.annotation.NonNull;
import org.eclipse.jdt.annotation.Nullable;

public class ReaderUtil {

    @NonNull
    public static StringBuilder read(@NonNull InputStream is, @Nullable Charset encoding) throws IOException {
        InputStream bis = new BufferedInputStream(is);
        return read(encoding == null ? new InputStreamReader(bis): new InputStreamReader(bis, encoding));
    }

    @NonNull
    public static StringBuilder read(Reader reader) throws IOException {
		try {
			StringBuilder sb = new StringBuilder();
			char[] buf = new char[1024];

			int n;
			while ((n = reader.read(buf)) != -1) {
				sb.append(buf, 0, n);
			}
			return sb;
		} finally {
		    reader.close();
		}
	}

	public static String readToString(@NonNull InputStream is, @Nullable Charset encoding) throws IOException {

		StringBuilder sb = read(is, encoding);
		return sb.length() == 0 ? null : sb.toString();
	}

    public static StringBuilder readFromUrl(@NonNull String urlString, int timeoutSecs,
        @Nullable Charset defaultCharSet) throws IOException {

        return read(getUrlReader(urlString, timeoutSecs, defaultCharSet));
    }

    public static Reader getUrlReader(@NonNull String urlString, int timeoutSecs,
        @Nullable Charset defaultCharSet) throws IOException {

        URL url = new URL(urlString);

        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        if (timeoutSecs > 0) {
            connection.setConnectTimeout(timeoutSecs * 1000);
            connection.setReadTimeout(timeoutSecs * 1000);
        }

        int responseCode = connection.getResponseCode();
        if (responseCode != HttpURLConnection.HTTP_OK) {
            throw new IOException("response code: " + responseCode);
        }

        Charset cs = getCharset(connection, defaultCharSet);
        if (cs == null) {
            cs = defaultCharSet;
        }

        InputStream is = new BufferedInputStream(Objects.requireNonNull(connection.getInputStream()));
        return cs == null ? new InputStreamReader(is): new InputStreamReader(is, cs);
    }

	@Nullable
    private static Charset getCharset(@NonNull HttpURLConnection connection, @Nullable Charset defaultCharset) {
        String contenttype = connection.getContentType();
        if (contenttype != null) {
            int charsetIdx = contenttype.indexOf("charset=");
            if (charsetIdx != -1) {
                String encoding = contenttype.substring(charsetIdx + 8);
                if (!encoding.isEmpty()) {
                    try {
                        return Charset.forName(encoding);
                    } catch (UnsupportedCharsetException ex) {
                    }
                }
            }
        }
        return defaultCharset;
    }


}