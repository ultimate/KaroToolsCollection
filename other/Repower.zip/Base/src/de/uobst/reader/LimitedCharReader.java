package de.uobst.reader;

import java.io.IOException;
import java.io.Reader;

/** Dieser Reader liest maximal eine bestimmte Anzahl Zeichen
 * bevor das Ende des Streams gemeldet wird.
 * Sch�tzt den Aufrufer davor, beliebig langen M�ll �ber das Netz zu bekommen
 *
 * @author ulli
 *
 */
public class LimitedCharReader extends Reader {
    private final Reader delegate;
    private int n; // Wieviel zeichen wirden schon gelesen? (n <= limit)
    private final int limit; // Maximale Anzahl von Zeichen
    private int markN; // n f�r Markierungen

    public LimitedCharReader(Reader delegate, int limit) {
        this.delegate = delegate;
        this.limit = limit;
    }

    @Override
    public void close() throws IOException {
        delegate.close();
    }

    @Override
    public int read(char[] buf, int offset, int count) throws IOException {
        if (n >= limit) {
            // Schon genug Zeichen gelesen.
            // Ende des Streams dem Aufrufer melden
            throw new IOException("read limit reached, limit: " + limit);
        }

        int r = delegate.read(buf, offset, Math.min(count, limit - n));
        if (r >= 0) {
            // Sicherstellen, dass kein �berlauf stattfindet
            n = (int)Math.min(Integer.MAX_VALUE, (long)n + r);
        }
        return r;
    }

    @Override
    public boolean markSupported() {
        return delegate.markSupported();
    }

    @Override
    public void mark(int readLimit) throws IOException {
        delegate.mark(readLimit);
        markN = n;
    }

    @Override
    public void reset() throws IOException {
        delegate.reset();
        n = markN;
    }

    @Override
    public int read() throws IOException {
        if (n >= limit) {
            return -1;
        }

        int c = delegate.read();
        if (c != -1) {
            n++;
        }
        return c;

    }

    @Override
    public boolean ready() throws IOException {
        return delegate.ready();
    }

    @Override
    public long skip(long charCount) throws IOException {
        return delegate.skip(charCount);
    }
}
