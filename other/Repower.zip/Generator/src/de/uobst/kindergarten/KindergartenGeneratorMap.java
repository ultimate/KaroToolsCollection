package de.uobst.kindergarten;

import de.uobst.generator.AbstractGeneratorMap;
import de.uobst.karobase.KaroBaseMap;

public class KindergartenGeneratorMap extends AbstractGeneratorMap {

    public KindergartenGeneratorMap(int height,
        int width, byte karocode) {
        super(height, width, karocode);
    }

    public KindergartenGeneratorMap(KaroBaseMap source) {
        super(source);
    }
}
