package de.uobst.kindergarten;

import static de.uobst.base.Arg.checkRange;
import static de.uobst.base.Range.correct;
import static de.uobst.base.collection.Lists.removeRandom;
import static de.uobst.karobase.KaroMapConstants.CP_MAX;
import static de.uobst.karobase.KaroMapConstants.CP_MIN;
import static de.uobst.karobase.KaroMapConstants.RASEN;
import static de.uobst.karobase.KaroMapConstants.START;
import static de.uobst.karobase.KaroMapConstants.ZIEL;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import de.uobst.base.Arg;
import de.uobst.generator.AbstractGenerator;
import de.uobst.generator.AbstractGeneratorMap;
import de.uobst.generator.Bar;
import de.uobst.generator.Gnubbel;
import de.uobst.generator.MapObject;
import de.uobst.generator.Rectangle;
import de.uobst.karobase.KaroMapConstants;
import de.uobst.karobase.Position;

public class Kindergarten extends AbstractGenerator {

    private static final String ALLOWED_ASPHALT = "O123456789";
    private static final String ALLOWED_OBJECTS = "XZYNWVGLT";

    private AbstractGeneratorMap gmap;
    private Random random;

    public Kindergarten() {
    }

    public static final int DEFAULT_WIDTH = 50;
    public static final int DEFAULT_HEIGHT = 50;
    public static final int DEFAULT_FILLLEVEL = 35;
    public static final int DEFAULT_CHECKPOINTS = 4;
    public static final int DEFAULT_PLAYERS = 5;
    public static final boolean DEFAULT_SCATTERED = false;
    public static final int DEFAULT_MIN_OBJECT_SIZE = 5;
    public static final int DEFAULT_MAX_OBJECT_SIZE = 10;
    public static final int DEFAULT_MIN_KAROS_PER_CPF = 3;
    public static final int DEFAULT_MAX_KAROS_PER_CPF = 4;
    public static final String DEFAULT_ASPHALT_SPEC = "O";
    public static final String DEFAULT_OBJECTS_SPEC = "XZYNWVGL";

    private static final int DEFAULT_FREQUENCY = 1;
    private static final int MINIMUM_FREQUENCY = 1;

    public static record Params(
        int width, // width of map
        int height, // height of map
        int filllevel, // fill level in %
        int checkpoints, // Anzahl Checkpoints
        int players, // Anzahl Checkpoints
        boolean scatteredStarts, //Verteilte Starts
        boolean scatteredCps, // Verteilte Checkpoints
        boolean scatteredFinishes, // Verteilte Ziele
        int minKarosPerCPF, // Anzahl karos pro Checkpoint
        int maxKarosPerCPF, // Anzahl karos pro Checkpoint
        int minObjectSize,
        int maxObjectSize,
        String asphaltSpec,
        String objectSpec
        ) {

        public Params() {
            this(DEFAULT_WIDTH,
                DEFAULT_HEIGHT,
                DEFAULT_FILLLEVEL,
                DEFAULT_CHECKPOINTS,
                DEFAULT_PLAYERS,
                DEFAULT_SCATTERED, DEFAULT_SCATTERED, DEFAULT_SCATTERED,
                DEFAULT_MIN_KAROS_PER_CPF,
                DEFAULT_MAX_KAROS_PER_CPF,
                DEFAULT_MIN_OBJECT_SIZE,
                DEFAULT_MAX_OBJECT_SIZE,
                DEFAULT_ASPHALT_SPEC,
                DEFAULT_OBJECTS_SPEC);
        }

        public void  check() {
            checkRange(width,  15,  250);
            checkRange(height,  15,  250);
            checkRange(filllevel,  0,  90);
            checkRange(checkpoints, 0, 9);
            checkRange(players, 1, 20);
            checkRange(minKarosPerCPF, 1, 10);
            checkRange(maxKarosPerCPF, 1, 10);
            checkRange(minObjectSize, 1, 50);
            checkRange(maxObjectSize, 1, 50);
            Arg.check(minObjectSize <= maxObjectSize, "min object size > max object size");
            Arg.check(minKarosPerCPF <= maxKarosPerCPF, "min karo per CPF > max karo per CPF");
        }

        public Params correctIfNecessary() {

            return new Params(
                correct(width,  15,  250),
                correct(height,  15,  250),
                correct(filllevel,  0,  90),
                correct(checkpoints,  0,  9),
                correct(players, 0, 20),
                scatteredStarts, scatteredCps, scatteredFinishes,
                correct(Math.min(minKarosPerCPF, maxKarosPerCPF), 1, 10),
                correct(Math.max(minKarosPerCPF, maxKarosPerCPF), 1, 10),
                correct(Math.min(minObjectSize, maxObjectSize), 1, 50),
                correct(Math.max(minObjectSize, maxObjectSize), 1, 50),
                asphaltSpec,
                objectSpec);
        }

    }

    public AbstractGeneratorMap generate(long seed, Params params) {
        return generate(new Random(seed), params);
    }


    public AbstractGeneratorMap generate(Random r, Params params) {
        int maxUnsuccessfullObjects = 5000;

        params.check();

        Map<Byte, Integer> asphaltMap = parseKarolist(params.asphaltSpec, ALLOWED_ASPHALT, false, DEFAULT_FREQUENCY, MINIMUM_FREQUENCY);
        Map<Byte, Integer> objectMap = parseKarolist(params.objectSpec, ALLOWED_OBJECTS, false, DEFAULT_FREQUENCY, MINIMUM_FREQUENCY);
        Set<Byte> asphalt = asphaltMap.keySet();

        random = r;

        gmap = new KindergartenGeneratorMap(params.height, params.width, asphaltMap.keySet().iterator().next());
        if (asphaltMap.size() > 1) {
            gmap.fillRandom(asphaltMap, random);
        }

        gmap.setRow(0, RASEN);
        gmap.setRow(params.height - 1, RASEN);
        gmap.setColumn(0, RASEN);
        gmap.setColumn(params.width - 1, RASEN);

        List<Rectangle> rectangles = gmap.getRandomRectangles(params.checkpoints + (params.scatteredFinishes ? 0 : 1), random);

        Rectangle maprect = gmap.getRectangle();

        setKaros(params.players, START, params.scatteredStarts, gmap.getRectangle(), asphalt);
        setKaros(getRandomIntInRange(params.minKarosPerCPF, params.maxKarosPerCPF() + 1), ZIEL, params.scatteredFinishes,
            params.scatteredFinishes? maprect : removeRandom(rectangles, random), asphalt);

        Set<Byte> usedCPs = new HashSet<>();
        usedCPs.addAll(asphalt);
        usedCPs.removeIf(karocode -> !KaroMapConstants.isCP(karocode));

        for (int i = 0; i < params.checkpoints && usedCPs.size() < 9; i++) {
            setKaros(getRandomIntInRange(params.minKarosPerCPF, params.maxKarosPerCPF() + 1),  getNextCP(usedCPs),
                params.scatteredCps, params.scatteredCps ? maprect : rectangles.get(i), asphalt);
        }

        int checkpointMask = gmap.getCheckpoints();

        int size = (gmap.getWidth() - 2) * (gmap.getHeight() - 2);

        KindergartenGeneratorMap.ReachableAnalysis ra;
        boolean raOk;
        int unsuccessfullObjects = 0;
        int reachablePositions = Integer.MAX_VALUE;
        int successfullObjects = 0;
        int totalObjectFrequency = objectMap.values().stream().mapToInt(i -> i).sum();
        do {
            MapObject mo = getRandomObject(params, getRandomKaro(objectMap, random.nextInt(totalObjectFrequency)));
            gmap.add(mo);
            ra = gmap.analyseReachablity(false, true);

            boolean reachablePositionsLowered;
            reachablePositionsLowered = ra.getReachablePositions() < reachablePositions;

            raOk = ra.isEverythingReachable(params.players, checkpointMask, params.minKarosPerCPF);

            if (!raOk || !reachablePositionsLowered) {
                gmap.undo(mo);
                unsuccessfullObjects++;
                if ((unsuccessfullObjects > maxUnsuccessfullObjects && successfullObjects > 0) || unsuccessfullObjects > maxUnsuccessfullObjects * 10) {
                    // hier geht gar nichts mehr, maxUnsuccessfull Objekte seit dem letzten Successfull object sind erreicht,
                    // bzw. Es konnte nach maxUnsuccessfullObjects Versuchen noch kein einziges Objekt hinzugef�gt werden.
                    break;
                }
            } else {
                unsuccessfullObjects = 0;
                reachablePositions = ra.getReachablePositions();
                successfullObjects ++;
            }

        } while(!raOk || (float)ra.getReachablePositions() * 100 / size > 100 - params.filllevel);
        // �u�erer Rasen Rahmen um die Karte
        gmap.setRow(0, RASEN);
        gmap.setRow(params.height - 1, RASEN);
        gmap.setColumn(0, RASEN);
        gmap.setColumn(params.width - 1, RASEN);

        return gmap;
    }

    private byte getNextCP(Set<Byte> usedCPs) {
        int c = random.nextInt(CP_MAX - CP_MIN - usedCPs.size());
        for (byte cp = CP_MIN + 1; cp <= CP_MAX; cp++) {
            if (!usedCPs.contains(cp)) {
                if (c-- == 0) {
                    usedCPs.add(cp);
                    return cp;
                }
            }
        }
        throw new IllegalStateException("Too many cps");
    }

    private MapObject getRandomObject(Params params, byte karocode) {
        return createBar(getRandomIntInRange(params.minObjectSize, params.maxObjectSize + 1), karocode);
    }

    private byte getRandomKaro(Map<Byte, Integer> available, int r) {
        for (var it = available.entrySet().iterator(); it.hasNext(); ) {
            var entry = it.next();
            if ((r -= entry.getValue()) < 0) {
                return entry.getKey();
            }
        }
        throw new IllegalStateException();
    }

    private Bar createBar(int maxsize, byte karocode) {
        double angle = random.nextDouble(2 * Math.PI);
        Position start = getRandomPosition(gmap.getRectangle());
        int y = (int)Math.round(maxsize * Math.sin(angle));
        int x = (int)Math.round(maxsize * Math.cos(angle));
        Position end = new Position(start.x + x, start.y + y);
        int thickness = getRandomIntInRange(1, Math.min(maxsize + 1,  6));
        return new Bar(start, end, thickness, karocode);
    }

    private void setKaros(int count, byte karocode, boolean scattered, Rectangle rectangle, Set<Byte> asphalt) {
        if (scattered) {
            addShatteredKaros(count, karocode, rectangle, asphalt);
        } else {
            addGnubbel(count, karocode, rectangle, asphalt);
        }
    }

    private void addShatteredKaros(int count, byte karocode, Rectangle rectangle, Set<Byte> asphalt) {
        int n = 0;
        while (n < count) {
            Position p = getRandomPosition(rectangle);
            if (asphalt.contains(gmap.get(p))) {
                gmap.set(p, karocode);
                n++;
            }
        }
    }

    int getRandomIntInRange(int min, int maxExclusive) {
        return min >= maxExclusive ? min : random.nextInt(min, maxExclusive);
    }

    private void addGnubbel(int count, byte karocode, Rectangle rectangle, Set<Byte> asphalt) {
        while(!gmap.addIfValid(new Gnubbel(getRandomPosition(rectangle), count, random, karocode), asphalt));
    }

    private Position getRandomPosition(Rectangle rectangle) {
        return new Position(random.nextInt(rectangle.width()) + rectangle.x(), random.nextInt(rectangle.height()) + rectangle.y());
    }

}
