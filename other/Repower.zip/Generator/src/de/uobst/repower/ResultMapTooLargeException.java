package de.uobst.repower;

@SuppressWarnings("serial")
public class ResultMapTooLargeException extends RepowerException{

    public ResultMapTooLargeException(String message) {
        super(message);
    }
}
