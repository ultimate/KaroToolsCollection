package de.uobst.repower;

@SuppressWarnings("serial")
public class MapNotDrivableException extends RepowerException {
    public MapNotDrivableException(String msg) {
        super(msg);
    }
}
