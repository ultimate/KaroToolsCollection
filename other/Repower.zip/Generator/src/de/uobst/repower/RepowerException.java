package de.uobst.repower;

import de.uobst.generator.GeneratorException;

@SuppressWarnings("serial")
public class RepowerException extends GeneratorException {

    public RepowerException(String message) {
        super(message);

    }

    public RepowerException(Exception ex) {
        super(ex);
    }

}
