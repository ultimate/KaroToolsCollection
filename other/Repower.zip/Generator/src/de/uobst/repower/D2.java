package de.uobst.repower;

import static de.uobst.base.collection.Lists.removeRandom;
import static de.uobst.karobase.KaroMapConstants.ASPHALT;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import org.eclipse.jdt.annotation.NonNull;
import org.eclipse.jdt.annotation.Nullable;

import de.uobst.generator.ConstrainedGnubbel;
import de.uobst.generator.EmptyMapObject;
import de.uobst.generator.MapObject;
import de.uobst.generator.Rectangle;
import de.uobst.karobase.Position;
import de.uobst.repower.R2Action.ActionContext;
import de.uobst.repower.R2Map.KaroKlumpen;
import de.uobst.repower.R2Map.MultiKlumpen;

public abstract class D2 {
    static List<D2> get(byte karocode, ActionContext context, @Nullable MultiKlumpen multiKlumpen) {
        KlumpenSpec klumpenSpec = context.params().klumpenSpecOf(karocode);
        List<D2> result = new ArrayList<>();
        // defered enthalt die Aktionen, die hinter den normalen kommen m�ssen
        List<D2> deferred = new ArrayList<>();

        List<KaroKlumpen> kls = multiKlumpen != null ? new ArrayList<>(multiKlumpen): Collections.emptyList();
        int msize = multiKlumpen != null ? multiKlumpen.size() : 0;
        boolean redistribute = context.params().redistribute(karocode);

        if (klumpenSpec.isUnspecified() && !redistribute) {
            return Collections.singletonList(new D2(karocode) {

                @Override
                public MapObject distribute(R2Map map, Rectangle rectangle)
                    throws RepowerException {
                    return new EmptyMapObject();
                }

                @Override
                public int getCount() {
                    return multiKlumpen != null ? multiKlumpen.positionSize(): 0;
                }
            });
        }
        Random random = context.random();
        int klumpenCount = klumpenSpec.isUnspecified() ? kls.size() : klumpenSpec.klumpenCount();

        // Objekte zum Entfernen von Klumpen
        for (int i = msize - klumpenCount - 1; i >= 0; i--) {
            result.add(new KlumpenRemover(karocode, removeRandom(kls, random)));
        }

        for (int i = klumpenCount - 1; i >= 0; i--) {
            KaroKlumpen klumpen = i < kls.size() ? kls.get(i) : null;

            if (i >= kls.size() || redistribute) {
                int klumpenSize = klumpenSpec.isUnspecified() ? klumpen != null ? klumpen.size() : 0 : klumpenSpec.klumpenSize();

                // Neuer Klumpen irgendwo, weil mehr als bestehende Klumpen angefordert wurden
                result.add(new KlumpenAdder(karocode, klumpenSize, klumpen, random));
            } else {
                int klumpenSize = klumpenSpec.isUnspecified() ? klumpen.size() : klumpenSpec.klumpenSize();
                // Vorhandenen Klumpen �ndern
                result.add(new KlumpenChanger(karocode, klumpenSize, klumpen, random));
            }
        }
        result.addAll(deferred);
        return result;
    }

    protected final byte karocode;

    private D2(byte karocode) {
        this.karocode = karocode;
    }

    public abstract MapObject distribute(R2Map map, Rectangle rectangle) throws RepowerException;
    public abstract int getCount();

    public void init(R2Map map) {
    }

    public boolean usesRectangle() {
        return false;
    }

    public boolean createsRandomPositions() {
        return false;
    }

    private void removeAll(KaroKlumpen klumpen, R2Map map) {
        klumpen.forEach(p -> map.set(p, ASPHALT));
    }

    private List<Position> getAsphaltInRectangle(Rectangle r, R2Map map) {
        return map.getPositionsByType(ASPHALT).stream().filter(r::contains).collect(Collectors.toList());
    }

    protected List<Position> getAsphalt(R2Map map) {
        return map.getPositionsByType(ASPHALT);
    }



    public static class KlumpenRemover extends D2 {
        private final KaroKlumpen klumpen;

        public KlumpenRemover(byte karocode, KaroKlumpen klumpen) {
            super(karocode);
            this.klumpen = klumpen;
        }

        @Override
        public void init(R2Map map) {
            super.removeAll(klumpen, map);
        }

        @Override
        public MapObject distribute(R2Map map, Rectangle rectangle) {
            return new EmptyMapObject();
        }

        @Override
        public int getCount() {
            return 0;
        }
    }

    public static class KlumpenAdder extends D2 {
        private final int count;
        @Nullable private final KaroKlumpen klumpen;
        private final Random random;

        public KlumpenAdder(byte karocode, int count, @Nullable KaroKlumpen klumpen, Random random) {
            super(karocode);
            this.count = count;
            this.klumpen = klumpen;
            this.random = random;
        }

        @Override
        public void init(R2Map map) {
            if (klumpen != null) {
                super.removeAll(klumpen, map);
            }
        }

        @Override
        public MapObject distribute(R2Map map, Rectangle rectangle) throws RepowerException {
            List<Position> asphaltPositions = null;

            if (rectangle != null) {
                asphaltPositions = super.getAsphaltInRectangle(rectangle, map);
                if (asphaltPositions.size() < count * 2) {
                // Don't use rectangle, too few positions or misplaced
                    asphaltPositions = null;
                }
            }


            if (asphaltPositions == null) {
                asphaltPositions = getAsphalt(map);
            }

            return new ConstrainedGnubbel(count, random, asphaltPositions, Collections.emptyList(), super.karocode);
        }

        @Override
        public boolean usesRectangle() {
            return true;
        }

        @Override
        public boolean createsRandomPositions() {
            return true;
        }

        @Override
        public int getCount() {
            return count;
        }
    }

    private static class KlumpenChanger extends D2 {
        private final int count;
        @NonNull
        private final KaroKlumpen klumpen;
        private final Random random;

        private boolean hasRandomPositions = false;

        public KlumpenChanger(byte karocode, int count, @NonNull KaroKlumpen klumpen, Random random) {
            super(karocode);
            this.count = count;
            this.klumpen = klumpen;
            this.random = random;
        }

        @Override
        public void init(R2Map map) {
            List<Position> positions = new ArrayList<>(klumpen);

            for (int i = 0; i < klumpen.size() - count; i ++) {
                map.set(removeRandom(positions, random), ASPHALT);
            }
        }

        @Override
        public MapObject distribute(R2Map map, Rectangle rectangle) throws RepowerException {
            if (count <= klumpen.size()) {
                return new EmptyMapObject();
            } else {
                List<Position> asphalt = getAsphalt(map);
                // Bereits neu gemappte Positionen aus dem Asphalt entfernen
                int remainingCount = count - klumpen.size();
                if (remainingCount < 0) {
                    throw new IllegalStateException();
                }
                List<Position> present = new ArrayList<>(klumpen);

                // Restliche Scattered Positions ausrechnen.
                ConstrainedGnubbel obj = new ConstrainedGnubbel(remainingCount, random, asphalt, present, karocode);
                return obj;
            }
        }

        @Override
        public int getCount() {
            return count;
        }

        @Override
        public boolean createsRandomPositions() {
            return hasRandomPositions;
        }
    }
}
