package de.uobst.repower;

import de.uobst.repower.Repower.Params;

public class RemapAction extends R2Action {

    @Override
    R2Map transform(ActionContext context, R2Map map)
        throws RepowerException {
        map.remap(context.remapSpecs(), context.random());
        return map;
    }

    @Override
    boolean isNeutral(Params params) {
        return params.remap().isBlank();
    }

}
