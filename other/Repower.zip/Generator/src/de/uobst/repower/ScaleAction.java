package de.uobst.repower;

import de.uobst.karobase.KaroMapConstants;
import de.uobst.karobase.Position;
import de.uobst.repower.Repower.Params;

public class ScaleAction extends R2Action {

    @Override
    R2Map transform(ActionContext context, R2Map map) throws RepowerException {
        int scalex = context.params().scalex();
        int scaley = context.params().scaley();
        if (scalex == Repower.RANDOM) {
            scalex = context.random().nextInt(150) + 50;
        }

        if (scaley == Repower.RANDOM) {
            scaley = context.random().nextInt(150) + 50;
        }

        int twidth = (int)(map.getWidth() * scalex / 100f);
        int theight = (int)(map.getHeight() * scaley / 100f);

        if (twidth <= 0 || theight <= 0) {
            throw new RepowerException("Fehler beim Skalieren. Die Karte wird zu klein (" + twidth + "*" + theight + " Karos)");
        }

        R2Map target = new R2Map(theight, twidth, KaroMapConstants.RASEN);
        for (int y = 0; y < theight; y ++) {
            int sy = (int)((y + 0.5) / theight * map.getHeight());
            for (int x = 0; x < twidth; x++) {
                int sx = (int)((x + 0.5) / twidth * map.getWidth());
                target.set(new Position(x, y), map.get(sx, sy));
            }
        }

        return target;
    }

    @Override
    boolean isNeutral(Params params) {
        return params.scalex() == 100 && params.scaley() == 100;
    }

}
