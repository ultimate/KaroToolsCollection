package de.uobst.repower;

import java.util.HashMap;

import de.uobst.karobase.Map2KaroMapTranslator;

@SuppressWarnings("serial")
public class CheckpointSpec extends HashMap<Byte, KlumpenSpec> {
    public static CheckpointSpec create(String s) {
        CheckpointSpec csp = new CheckpointSpec();
        csp.putAll(Repower.parseKarolist(s, "123456789", true, KlumpenSpec::create));
        return csp;
    }

    KlumpenSpec get(byte karocode) {
        return getOrDefault(karocode, KlumpenSpec.UNSPECIFIED);
    }
    boolean isUnspecified() {
        return values().stream().allMatch(s -> s.isUnspecified());
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        KlumpenSpec pending = null;
        for (var entry : entrySet()) {
            if (pending != null && !pending.equals(entry.getValue())) {
                sb.append(":");
                sb.append(pending);
                sb.append(",");
            }
            sb.append(Map2KaroMapTranslator.translateToDidiCode(entry.getKey()));
            pending = entry.getValue();
        }
        if (pending != null && !sb.isEmpty()) {
            sb.append(":");
            sb.append(pending);
        }
        return sb.toString();
    }
}