package de.uobst.repower;

import de.uobst.repower.Repower.Params;

public class MirrorAction extends R2Action {

    @Override
    R2Map transform(ActionContext context, R2Map map) {
        boolean mirrorx = context.params().mirrorx();
        boolean mirrory = context.params().mirrory();
        if (mirrorx) {
            map.mirrorX();
        }

        if (mirrory) {
            map.mirrorY();
        }

        return map;
    }

    @Override
    boolean isNeutral(Params params) {
        return !params.mirrorx() && !params.mirrory();
    }

}
