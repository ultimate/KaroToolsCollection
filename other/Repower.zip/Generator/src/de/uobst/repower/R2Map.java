
package de.uobst.repower;

import static de.uobst.karobase.KaroMapConstants.START;
import static de.uobst.karobase.KaroMapConstants.ZIEL;

import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.eclipse.jdt.annotation.Nullable;

import de.uobst.base.collection.IteratorChain;
import de.uobst.base.collection.TransformingIterator;
import de.uobst.generator.AbstractGenerator.Frequence;
import de.uobst.generator.AbstractGeneratorMap;
import de.uobst.karobase.KaroBaseMap;
import de.uobst.karobase.KaroMapConstants;
import de.uobst.karobase.Position;
import de.uobst.repower.Repower.RemapSpec;

/** Karopapier Map f�r den Repower Generator, der viele Operationen auf die Karte enth�lt,
 * die der Repower Generator braucht
 */
public class R2Map extends AbstractGeneratorMap {

    private static final double KLUMPEN_DIST_INDICATOR = 2.9;

    /** Ein KaroKlumpen ist eine Anzahl von Positionen, die alle nicht weiter als
     * {@link R2Map#KLUMPEN_DIST_INDICATOR} voneinander entfernt sind
     */
    @SuppressWarnings("serial")
    public static class KaroKlumpen extends HashSet<Position> {
        KaroKlumpen() {
        }

        KaroKlumpen(Collection<Position> source) {
            super();
            addAll(source);
        }

        /** Pr�ft, ob candidate in diesen Klumpen aufgenommen werden kann
         * (n�mlich dann, wenn die Distanz zu mindestens einer enthaltenen
         * Position < {@link #KLUMPEN_DIST_INDICATOR} ist, oder wenn dieser Klumpen leer ist
         * @param candidate
         * @return
         */
        boolean canKlump(Position candidate) {
            return isEmpty() || stream().anyMatch(p -> p.distance(candidate) < KLUMPEN_DIST_INDICATOR);
        }

        /** Pr�ft, ob der Klumpen k in diesen Klumpen aufgenommen werden kann,
         * (na�mlci dann, wenn mindestens eine Position aus k aufgenommen werden kann)
         * @param k
         * @return
         */
        boolean canKlump(KaroKlumpen k) {
            return k.stream().anyMatch(this::canKlump);
        }
    }

    @SuppressWarnings("serial")
    public static class MultiKlumpen extends ArrayList<KaroKlumpen> {
        MultiKlumpen(Collection<Position> positionen) {
            positionen.forEach(this::add);
        }

        public MultiKlumpen() {
        }

        /** F�gt die Position p zu dem Multiklumpen hinzu, indem
         * untersucht, in welchen Klumpen die Position hineinpasst.
         * Achtung: Es kann mehrere Klumpen geben, in die p passt, in diesem Fall werden die Klumpen
         * durch p zu einem Klumpen. Gibt es keinen Klumpen in den p passt, wird ein neuer erzeugt
         * @param p
         * @return
         */
        public boolean add(Position p) {
            KaroKlumpen klumpenContainingP = null;

            for (Iterator<KaroKlumpen> kiter = iterator(); kiter.hasNext(); ) {
                KaroKlumpen k = kiter.next();
                if (k.canKlump(p)) {
                    if (klumpenContainingP != null) {
                        // merge
                        klumpenContainingP.addAll(k);
                        kiter.remove();
                    } else {
                        if (!k.add(p)) {
                            // War schon vorhanden
                            return false;
                        }
                        klumpenContainingP = k;
                    }
                }
            }
            if (klumpenContainingP == null) {
                KaroKlumpen k = new KaroKlumpen();
                k.add(p);
                add(k);
            }
            return true;
        }

        /** Anzahl Positionen in diesem MultiKlumpen
         */
        int positionSize() {
            return stream().mapToInt(k -> k.size()).sum();
        }

        public Collection<Position> positionen() {
            return new AbstractCollection<Position>() {
                @Override
                public Iterator<Position> iterator() {
                    return new IteratorChain<>(new TransformingIterator<>(MultiKlumpen.this.iterator(), list -> list.iterator()));

                }

                @Override
                public int size() {
                    return positionSize();
                }

                @Override
                public boolean add(Position e) {
                    return MultiKlumpen.this.add(e);
                }
            };
        }
    }

    @SuppressWarnings("serial")
    public static class MegaKlumpen extends HashMap<Byte, MultiKlumpen> {
        public void add(byte karocode, Position p) {
            MultiKlumpen mk = get(karocode);
            if (mk == null) {
                mk = new MultiKlumpen();
                put(karocode, mk);
            }
            mk.add(p);
        }
    }


    /** Enth�lt die Characteristik einer Karte, d.h. wie Start, Ziele und Checkpoints auf der Karte
     * zusammenh�ngen, liegen sie als Klumpen an einer Stelle oder sind sie �ber die Karte verstreut
     */
    record MapCharacteristics(MultiKlumpen starts, MultiKlumpen ziele, MegaKlumpen cps) {

        /** Liefert den MultiKlumpen zu dem angegebenen karocode (oder null)
         *
         * @param karocode
         * @return
         */
        @Nullable MultiKlumpen multiklumpen(byte karocode) {
            return
                switch(karocode) {
                case START -> starts;
                case ZIEL -> ziele;
                default -> cps.get(karocode);
                };
        }

    }

    public R2Map(KaroBaseMap source) {
        super(source);
    }

    public R2Map(int height, int width, byte karocode) {
        super(height, width, karocode);
    }

    MapCharacteristics getMapCharacteristics() {
        boolean[][] reached = new boolean[getHeight()][getWidth()];

        MultiKlumpen startPositions = new MultiKlumpen(getPositionsByType(START));
        List<Position> positions = new ArrayList<>(startPositions.positionen());
        positions.forEach(p -> reached[p.y][p.x] = true);
        MegaKlumpen cpPositions = new MegaKlumpen();
        MultiKlumpen ziele = new MultiKlumpen();

        while(!positions.isEmpty()) {
            List<Position> next = new ArrayList<>();
            for (Position p : positions) {
                for (int i = 0; i < 9; i++) {
                    int x = p.x + i / 3 - 1;
                    int y = p.y + i % 3 - 1;
                    byte karocode;

                    if (isValidPosition(x, y) && !reached[y][x] && KaroMapConstants.isDriveable(karocode = get(x, y))) {
                        reached[y][x] = true;
                        Position n = new Position(x, y);

                        switch(karocode) {
                        case START -> throw new IllegalStateException();
                        case ZIEL -> ziele.add(n);
                        default -> {
                            if (KaroMapConstants.isCP(karocode)) {
                                cpPositions.add(karocode, n);
                            }}
                        }
                        next.add(n);
                    }
                }
            }
            positions = next;
        }


        return new MapCharacteristics(startPositions, ziele, cpPositions);
    }

    /**
     * Das Ergebnis einer Rotation
     * @param map Die rotierte Karte
     * @param nullPosition die Position, an der die Position 0,0 (linke obere Ecke)
     * der Ausgangskarte in der neuen Karte zu liegen kommt.
     */
    record RotationResult(R2Map map, Position nullPosition) {}

    /** @param angle 0 bis 2 * PI
     */
    RotationResult rotate(double angle, byte bg) {
        Position targetP0 = transform(0.5, 0.5, angle);
        Position targetP1 = transform(getWidth() + 0.5, angle);
        Position targetP2 = transform(getWidth() + 0.5, getHeight() + 0.5, angle);
        Position targetP3 = transform(getHeight() + 0.5, angle + Math.PI / 2);

        int targetLeft = min(targetP1.x, targetP2.x, targetP3.x, targetP0.x);
        int targetRight = max(targetP1.x, targetP2.x, targetP3.x, targetP0.x);
        int targetTop = min(targetP1.y, targetP2.y, targetP3.y, targetP0.y);
        int targetBottomn = max(targetP1.y, targetP2.y, targetP3.y, targetP0.y);

        int twidth = targetRight - targetLeft;
        int theight = targetBottomn - targetTop;

        Position targetNormP0 = new Position((targetP0.x - targetLeft) * 2 + 1, (targetP0.y - targetTop) * 2 + 1);
        Position targetNormP1 = new Position((targetP1.x - targetLeft) * 2 + 1, (targetP1.y - targetTop) * 2 + 1);
        Position targetNormP2 = new Position((targetP2.x - targetLeft) * 2 + 1, (targetP2.y - targetTop) * 2 + 1);
        Position targetNormP3 = new Position((targetP3.x - targetLeft) * 2 + 1, (targetP3.y - targetTop) * 2 + 1);

        R2Map target = new R2Map(theight, twidth, bg);

        for (int y = 0; y < theight; y ++) {
            for (int x = 0; x < twidth; x++) {
                if (!ViereckCalculator.inViereck(targetNormP0,  targetNormP1,  targetNormP3,  targetNormP2, new Position(x * 2 + 1,  y * 2 + 1))) {
                    continue;
                }
                Position s = transform(x + targetLeft + 0.5, y + targetTop + 0.5, -angle);
                if (isValidPosition(s)) {
                    target.set(x, y, get(s));
                }
            }
        }

        return new RotationResult(target, new Position(targetLeft, targetTop));
    }

    /** Berechnet, an welcher Position ein Vektor der L�nge l (beginnend bei 0, 0) mit dem Winkel angle
     * liegt.
     * @param l Die L�nge
     * @param angle Der winkel in Radiant
     * @return Die Position auf dieser Karte (abgerundet)
     */
    public static Position transform(double l, double angle) {
        return new Position((int)(l * Math.cos(angle)), (int)(l * Math.sin(angle)));
    }

    /** Berechnet an welcher Position eine Position x, y zu liegen kommt, wenn die um den Winkel angle rotiert wird
    *
    * @param x X Koordinate der Position
    * @param y y Koordinate der Position
    * @param angle Der Winkel in Radiant
    * @return Die Position (abgerundet)
    */
    public static Position transform(double x, double y, double angle) {
        return transform(Math.sqrt(x * x + y * y), Math.atan2(y, x) + angle);
    }

    void mirrorX() {
        int w = getWidth();
        int mx = w / 2;
        w--;
        for (int y = 0; y < getHeight(); y++) {
            for (int x = 0; x < mx; x++) {
                byte karocode = get(x, y);
                set(x, y, get(w - x, y));
                set(w - x, y, karocode);
            }
        }
    }
    void mirrorY() {
        int h = getHeight();
        int my = h / 2;
        h--;
        for (int x = 0; x < getWidth(); x++) {
            for (int y = 0; y < my; y++) {
                byte karocode = get(x, y);
                set(x, y, get(x, h - y));
                set(x, h - y, karocode);
            }
        }
    }

    Position mirror(Position p, boolean mirrorx, boolean mirrory) {
        return new Position(
            mirrorx ? getWidth()  - 1 - p.x : p.x,
            mirrory ? getHeight() - 1 - p.y : p.y);
    }

    private static int min(int i1, int i2, int i3, int i4) {
        return Math.min(Math.min(i1,  i2), Math.min(i3,  i4));
    }

    private static int max(int i1, int i2, int i3, int i4) {
        return Math.max(Math.max(i1,  i2), Math.max(i3,  i4));
    }

    public boolean isSolidRow(int row) {
        return IntStream.range(0, getWidth()).allMatch(column -> !isDriveable(column, row));
    }

    public boolean isSolidColumn(int column) {
        return IntStream.range(0, getHeight()).allMatch(row -> !isDriveable(column, row));
    }

    public void remap(RemapSpec remapSpecs, Random random) {
        Map<Byte, Integer> totalFrequence = remapSpecs.entrySet().stream().collect(Collectors.toMap(
            e -> e.getKey(),
            e -> e.getValue().stream().mapToInt(p -> p.frequence()).sum()));

        for (int y = getHeight() - 1; y >= 0; y--) {
            for (int x = getWidth() - 1; x >= 0; x--) {
                byte karocode = get(x, y);
                var frequenceList = remapSpecs.get(karocode);
                if (frequenceList != null) {
                    if (frequenceList.size() == 1) {
                        set(x, y, frequenceList.get(0).karocode());
                    } else {
                        set(x, y, getKarocodeFromFrequenceList(frequenceList, random.nextInt(totalFrequence.get(karocode))));
                    }
                }
            }
        }
    }

    private byte getKarocodeFromFrequenceList(List<Frequence> frequenceList, int n) {
        int i = -1;
        do {
            n -= frequenceList.get(++i).frequence();
        } while(n >= 0);
        return frequenceList.get(i).karocode();
    }
}
