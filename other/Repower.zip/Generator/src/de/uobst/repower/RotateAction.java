package de.uobst.repower;

import static de.uobst.repower.Repower.UNSPECIFIED_KAROCODE;

import de.uobst.repower.R2Map.RotationResult;
import de.uobst.repower.Repower.Params;

public class RotateAction extends R2Action {

    @Override
    R2Map transform(ActionContext context, R2Map map) throws RepowerException {
        int a =  context.params().angle();
        if (a == Repower.RANDOM) {
            a = context.random().nextInt(360);
        }

        double angle = a / 180.0 * Math.PI;

        RotationResult result =  map.rotate(angle, UNSPECIFIED_KAROCODE);
        R2Map m = result.map();

        while(m.removeRowIf(0, UNSPECIFIED_KAROCODE));
        while(m.removeRowIf(m.getHeight() - 1, UNSPECIFIED_KAROCODE));
        while(m.removeColumnIf(m.getWidth() - 1, UNSPECIFIED_KAROCODE));
        while(m.removeColumnIf(0, UNSPECIFIED_KAROCODE));

        return m;
    }

    @Override
    boolean isNeutral(Params params) {
        return params.angle() == 0;
    }

}
