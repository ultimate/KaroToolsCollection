package de.uobst.repower;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import org.eclipse.jdt.annotation.NonNull;
import org.eclipse.jdt.annotation.Nullable;

import de.uobst.karobase.KaroBaseMap;
import de.uobst.repower.Repower.Params;
import de.uobst.repower.Repower.RemapSpec;

/** Abstrakte Oberklasse f�r alle Actions des repower generators
 */
public abstract class R2Action {

    record ActionContext (
        Params params,
        Random random,
        KaroBaseMap originalMap,
        RemapSpec remapSpecs) {

    }


    @SuppressWarnings("serial")
    static final Map<Integer, R2Action> actionMap = new LinkedHashMap<>() {{
        put((int)'I', new MirrorAction());
        put((int)'S', new ScaleAction());
        put((int)'T', new TileAction());
        put((int)'R', new RotateAction());
        put((int)'D', new DistributeAction());
        put((int)'M', new RemapAction());
        put((int)'B', new PrepareBorderAction());
        put((int)'C', new CheckAction());

    }};

    @Nullable
    static R2Action get(int c) {
        return actionMap.get(c);
    }

    static String getAllActions() {
        return actionMap.keySet().stream().map(c -> Character.toString(c)).collect(Collectors.joining());
    }

    @NonNull
    abstract R2Map transform(ActionContext context, R2Map map) throws RepowerException;
    abstract boolean isNeutral(Repower.Params params);

}
