package de.uobst.repower;

import static de.uobst.base.collection.CollectionUtils.first;
import static de.uobst.base.collection.Lists.getRandom;
import static de.uobst.repower.Repower.UNSPECIFIED_KAROCODE;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import de.uobst.base.collection.CollectionUtils;
import de.uobst.base.collection.ListList;
import de.uobst.generator.AbstractGeneratorMap;
import de.uobst.generator.Bar;
import de.uobst.generator.Rectangle;
import de.uobst.karobase.KaroMapConstants;
import de.uobst.karobase.Position;
import de.uobst.repower.Repower.Params;

public class TileAction extends R2Action {

    /**
     * @param h Anzahl Kacheln horizontal
     * @param Anzahl Kacheln vertikal
     * @param hc Horizontaler Connector
     * @param vc Vertikater Connector
     */
    record TileSpec(int h, int v, char hc, char vc) {
        TileSpec(String spec) {
            this(spec.length() > 0 && Character.isDigit(spec.charAt(0))? Integer.parseInt(spec.substring(0, 1)) : 1,
                spec.length() > 2 && Character.isDigit(spec.charAt(2))? Integer.parseInt(spec.substring(2, 3)) : 1,
                spec.length() > 4 ? spec.charAt(4): 'N',
                spec.length() > 5 ? spec.charAt(5): 'N');
        }

        @Override
        public String toString() {
            return h + "*" + v + '/' + hc + vc;
        }
    }

    public enum Connector {
        CUT {
            @Override
            R2Map connect(R2Map m1, AbstractGeneratorMap m2, byte bg, Random random) throws RepowerException {
                return connectHorizontalByCut(m1, m2, bg);
            }
        },

        ASPHALT {

            @Override
            R2Map connect(R2Map m1, AbstractGeneratorMap m2, byte bg, Random random) throws RepowerException {
                return connectByAsphalt(m1, m2, bg, random);
            }
        },

        NOTHING {

            @Override
            R2Map connect(R2Map m1, AbstractGeneratorMap m2, byte bg, Random random) throws RepowerException {
                return connectHorizontal(m1, m2, bg);
            }
        };

        static Connector get(char key) {
            return key == 'A' ? ASPHALT : key == 'C' ? CUT : NOTHING;
        }

        abstract R2Map connect(R2Map m1, AbstractGeneratorMap m2, byte bg, Random random) throws RepowerException;
    }

    @Override
    R2Map transform(ActionContext context, R2Map map) throws RepowerException {
        TileSpec ts = new TileSpec(context.params().tile());

        if (ts.h > 1) {
            map= tile(map,  ts.hc , ts.h, UNSPECIFIED_KAROCODE, context.random());
        }

        // Die Vertikale Tile Operation wird gemacht, indem die Karte um 90 Grad gedreht,
        // dann das ganze horizontal durchgef�hrt wird, und zum Schluss 90 Grad
        // wieder zur�ckgedreht wird
        if (ts.v() > 1) {
            map = map.rotate(Math.PI * 3 / 2, UNSPECIFIED_KAROCODE).map();
            map = tile(map, ts.vc, ts.v, UNSPECIFIED_KAROCODE, context.random());
            map = map.rotate(Math.PI / 2, UNSPECIFIED_KAROCODE).map();
        }

        return map;
    }

    /** H�ngt die Karte count Mal hintereinander (horizontal)
     *
     * @param map Die Karte
     * @param connectorKey Wie die Karten miteinander verbunden werden
     * @param count Die Anzahl, wie oft die Karte hintereinander geh�ngt wird
     * @param bg Der Hintergrund f�r neu entstehende Kartenteile (bei ASPHALT Connector)
     * @param random Der Zufalls
     * @return eine Karte, die die Ausgangskarte count mal hintereinander geh�ngt hat
     * @throws RepowerException
     */
    private static R2Map tile(R2Map map, char connectorKey, int count, byte bg, Random random) throws RepowerException {
        R2Map workmap = new R2Map(map);

        Connector c = Connector.get(connectorKey);

        for (int i = 1; i < count; i++) {
            R2Map m2 = new R2Map(map);
            workmap =  c.connect(workmap, m2, bg, random);
        }
        return workmap;
    }


    private static R2Map connectHorizontalByCut(R2Map m1, AbstractGeneratorMap m2, byte bg) throws RepowerException {
        int i = 0;
        List<Position> m1positions;
        do {
             m1positions = m1.getDrivablesInColumn(m1.getWidth() - 1 - i);
            var m2positions = m2.getDrivablesInColumn(i);
            final int cc = i;
            m1positions.forEach(p -> p.x = cc);
            m1positions.retainAll(m2positions);
        } while(m1positions.isEmpty() && ++i < m1.getWidth() && i < m2.getWidth());

        if (m1positions.isEmpty()) {
            throw new RepowerException("Can't connect maps horizontally using shrink algorithm");
        }

        R2Map resultMap =
            new R2Map(
                Math.max(m1.getHeight(), m2.getHeight()),
                m1.getWidth() + m2.getWidth() - 2 * i,
                bg);

        resultMap.copyFrom(m1, new Rectangle(0, 0, m1.getWidth(), m1.getHeight()), new Position(0, 0), false);
        resultMap.copyFrom(m2, new Rectangle(i, 0, m2.getWidth() - i, m2.getHeight()), new Position(m1.getWidth() - i, 0), true);

        return resultMap;
    }

    private static R2Map connectByAsphalt(R2Map m1, AbstractGeneratorMap m2, byte bg, Random random) throws RepowerException {
        List<Position>  m1positions;
        List<Position>  m2positions;

        int m1col = m1.getWidth() - 1;
        do {
            m1positions = m1.getDrivablesInColumn(m1col);
        } while(m1positions.isEmpty() && --m1col > 0);

        int m2col = 0;
        do {
            m2positions = m2.getDrivablesInColumn(m2col);
        } while(m2positions.isEmpty() && ++m2col < m2.getWidth());

        if (m1positions.isEmpty() || m2positions.isEmpty()) {
            throw new RepowerException("Can't connect maps horizontally using asphalt algorithm");
        }

        var l1 = getConnectPositions(m1positions);
        var l2 = getConnectPositions(m2positions);
        List<ConnectPair> connectPairs = getNearestConnectPairs(l1, l2);
        ConnectPair connect = connectPairs.size() == 1 ? first(connectPairs) : getRandom(connectPairs, random);

        var resultMap = connectHorizontal(m1, m2, bg);
        connect.p2.x += m1.getWidth();
        resultMap.add(new Bar(connect.p1, connect.p2, 4, KaroMapConstants.ASPHALT));

        return resultMap;
    }

    private static List<Position> getConnectPositions(List<Position> positions) {
        List<Position> currentSet = new ArrayList<>();
        List<Position> connectionPositions = new ArrayList<>();
        int maxConnectSize = 0;

        for (Position p : new ListList<>(positions, Collections.singletonList(new Position(0, 0)))) {
            if (!currentSet.isEmpty()) {
                if (p.distance(CollectionUtils.last(currentSet)) > 2.1) {
                    if (currentSet.size() >= maxConnectSize) {
                        if (currentSet.size() > maxConnectSize) {
                            connectionPositions.clear();
                            maxConnectSize = currentSet.size();
                        }

                        Position center = Position.center(currentSet);
                        connectionPositions.add(center);
                    }
                    currentSet.clear();
                }
            }
            currentSet.add(p);
        }

        return connectionPositions;
    }

    private record ConnectPair(Position p1, Position p2){}

    private static List<ConnectPair> getNearestConnectPairs(List<Position> l1, List<Position> l2) {
        List<ConnectPair> pairs = new ArrayList<>();
        double minDistance = Double.MAX_VALUE;

        for (var p1 : l1) {
            for (var p2 : l2) {
                var d = p1.distance(p2);
                if (d <= minDistance) {
                    if (d < minDistance) {
                        pairs.clear();
                        minDistance = d;
                    }
                    pairs.add(new ConnectPair(p1,  p2));
                }
            }
        }
        return pairs;
    }

    private static R2Map connectHorizontal(AbstractGeneratorMap m1, AbstractGeneratorMap m2, byte bg) {
        R2Map resultMap =
            new R2Map(
                Math.max(m1.getHeight(), m2.getHeight()),
                m1.getWidth() + m2.getWidth(),
                bg);

        resultMap.copyFrom(m1, new Rectangle(0, 0, m1.getWidth(), m1.getHeight()), new Position(0, 0), false);
        resultMap.copyFrom(m2, new Rectangle(0, 0, m2.getWidth(), m2.getHeight()), new Position(m1.getWidth(), 0), false);

        return resultMap;
    }

    @Override
    boolean isNeutral(Params params) {
        TileSpec ts = new TileSpec(params.tile());
        return ts.h == 1 && ts.v == 1;
    }


}
