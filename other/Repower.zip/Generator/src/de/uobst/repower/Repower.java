package de.uobst.repower;

import static de.uobst.base.Range.correct;
import static de.uobst.karobase.KaroMapConstants.START;
import static de.uobst.karobase.KaroMapConstants.ZIEL;
import static de.uobst.karobase.Map2KaroMapTranslator.getAllKnownDidiCodes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.regex.Pattern;

import de.uobst.generator.AbstractGenerator;
import de.uobst.generator.AbstractGeneratorMap;
import de.uobst.karobase.KaroBaseMap;
import de.uobst.karobase.KaroMapConstants;

public class Repower extends AbstractGenerator{

    private static int DEFAULT_MID = 0;
    public static int RANDOM = -1;
    public static int DEFAULT_SCALE = 100;
    public static int DEFAULT_ANGLE = 0;
    public static final boolean DEFAULT_MIRROR = false;
    public static final boolean DEFAULT_REDIST = false;
    public static final KlumpenSpec DEFAULT_PLAYERS = new KlumpenSpec();
    public static final KlumpenSpec DEFAULT_ZIELE = new KlumpenSpec();
    public static final CheckpointSpec DEFAULT_CHECKPOINTS = new CheckpointSpec();
    public static final String DEFAULT_TILE = "1*1/CC";
    public static final char UNSPECIFIED_DIDICODE = '@';
    public static final byte UNSPECIFIED_KAROCODE = (byte)'@';
    public static String DEFAULT_ACTIONS = R2Action.getAllActions();

    static final int CURRENT_COUNT = -1;
    static final int MAX_TRIES = 20;

    static final Pattern SPEC_PATTERN = Pattern.compile(" *([0-9]+) *(\\* *([0-9]+))?");

    public static record Params (
        int mid,
        int scalex,
        int scaley,
        int angle,
        boolean mirrorx,
        boolean mirrory,
        boolean redistributeStarts,
        boolean redistributeFinishs,
        boolean redistributeCPs,
        KlumpenSpec players,
        KlumpenSpec ziele,
        CheckpointSpec checkpoints,
        String remap,
        String tile,
        String actions
    ) {

        public Params() {
            this(DEFAULT_MID,
                DEFAULT_SCALE,
                DEFAULT_SCALE,
                DEFAULT_ANGLE,
                DEFAULT_MIRROR,
                DEFAULT_MIRROR,
                DEFAULT_REDIST,
                DEFAULT_REDIST,
                DEFAULT_REDIST,
                DEFAULT_PLAYERS,
                DEFAULT_ZIELE,
                DEFAULT_CHECKPOINTS,
                "",
                DEFAULT_TILE,
                DEFAULT_ACTIONS);
        }

        public Params correctIfNecessary() {
            return new Params(mid,
                scalex != RANDOM ? correct(scalex, 0, 1000): RANDOM,
                scaley != RANDOM ? correct(scaley, 0, 1000): RANDOM,
                angle != RANDOM ? Math.floorMod(angle, 360): RANDOM,
                mirrorx,
                mirrory,
                redistributeStarts,
                redistributeFinishs,
                redistributeCPs,
                players,
                ziele,
                checkpoints,
                remap,
                tile.isBlank() ? DEFAULT_TILE : tile,
                actions.isBlank() ? DEFAULT_ACTIONS : actions);

        }

        public boolean redistribute(byte karocode) {
            return switch(karocode) {
                case START -> redistributeStarts;
                case ZIEL -> redistributeFinishs;
                default -> redistributeCPs && checkpoints.containsKey(karocode);
            };
        }

        KlumpenSpec klumpenSpecOf(byte karocode) {
            return switch(karocode) {
                case START -> players;
                case ZIEL ->  ziele;
                default -> checkpoints.get(karocode);
            };
        }

        public RemapSpec createRemapSpecs() {
            return new RemapSpec(parseFrequenceKarolist(remap, getAllKnownDidiCodes() + UNSPECIFIED_DIDICODE, true, 1, 1));
        }

        public boolean isRandomUsed() {
            return mid == RANDOM || angle == RANDOM || scalex == RANDOM || scaley == RANDOM;
        }
    }

    @SuppressWarnings("serial")
    static class RemapSpec extends HashMap<Byte, List<Frequence>> {
        RemapSpec(Map<Byte, List<Frequence>> source) {
            super(source);
        }

        RemapSpec(byte key, byte karocode) {
            put(key, Collections.singletonList(new Frequence(karocode, 1)));
        }

        protected RemapSpec() {
        }
    }

    @SuppressWarnings("serial")
    private RemapSpec createUnspecifiedMapping(KaroBaseMap original, RemapSpec rspec) {
        if (rspec.containsKey(UNSPECIFIED_KAROCODE)) {
            return new RemapSpec(){{
                put(UNSPECIFIED_KAROCODE, rspec.get(UNSPECIFIED_KAROCODE));
            }};

        } else {
            byte tr = original.get(original.getWidth() - 1, 0);
            tr = KaroMapConstants.isDriveable(tr) ? KaroMapConstants.RASEN : tr;
            return new RemapSpec(UNSPECIFIED_KAROCODE, tr);
        }
    }

    public AbstractGeneratorMap generate(Params params, Random random, KaroBaseMap map) throws RepowerException {
        R2Map originalCopy = new R2Map(map);
        RemapSpec rspec = params.createRemapSpecs();
        RemapSpec uspec = createUnspecifiedMapping(map, rspec);
        rspec.remove(UNSPECIFIED_KAROCODE);

        R2Action.ActionContext context =
            new R2Action.ActionContext(
                params,
                random,
                originalCopy,
                rspec);

        // Liste der auszuf�hrenden Transformationen erstellen
        List<R2Action> actions = new ArrayList<>();
        for (int i = 0; i < params.actions.length(); i++) {
            char c = params.actions.charAt(i);
            R2Action op = R2Action.get(c);
            if (op == null) {
                throw new RepowerException("Unknown action: " + c);
            }

            if (!op.isNeutral(params)) {
                actions.add(op);
            }
        }

        // Alle Transformationen durchf�hren
        R2Map transformed = new R2Map(map);
        for (R2Action op : actions) {
            transformed = op.transform(context, transformed);
        }

        // Den unspezifizierten Karocode auch mappen
        transformed.remap(uspec, random);
        return transformed;
    }

}
