package de.uobst.repower;

import java.util.regex.Matcher;

import de.uobst.base.Strings;
import de.uobst.repower.R2Map.MultiKlumpen;

/**
 * @param klumpenCount Anzahl Klumpen
 * @param klumpenSize Anzahl Karos pro Klumpen
 */
public record KlumpenSpec (int klumpenCount, int klumpenSize) {
    public static final KlumpenSpec UNSPECIFIED = new KlumpenSpec();

    public static KlumpenSpec create (String spec) {
        if (spec != null && !spec.isBlank()) {
            Matcher matcher = Repower.SPEC_PATTERN.matcher(spec);
            if (matcher.matches()) {
                int klumpenSize = Integer.parseInt(matcher.group(1));
                int klumpenCount = 1;
                if (matcher.groupCount() == 3 && !Strings.isEmpty(matcher.group(3))) {
                    klumpenCount = klumpenSize;
                    klumpenSize = Integer.parseInt(matcher.group(3));
                }
                return new KlumpenSpec(klumpenCount, klumpenSize);
            }
        }
        return UNSPECIFIED;
    }

    public KlumpenSpec() {
        this(Repower.CURRENT_COUNT, 1);
    }

    public int getTotelSize() {
        return klumpenCount * klumpenSize;
    }
    boolean isUnspecified() {
        return klumpenCount == Repower.CURRENT_COUNT;
    }
    boolean isEmpty(MultiKlumpen mk) {
        return getTotelSize() == 0 || (isUnspecified() && mk.positionSize() == 0);
    }
    @Override
    public String toString() {
        return isUnspecified() ? "": klumpenCount == 1? String.valueOf(klumpenSize) : klumpenCount + "*" + klumpenSize;
    }

}