package de.uobst.repower;

import de.uobst.karobase.Position;

public class ViereckCalculator {

    public static boolean inRange(int a, int b, int p) {
        return a < b ? a <= p && p <= b : b <= p && p <= a;
    }

    public static boolean inLinie(Position A, Position B, Position P) {
        return inRange(A.x, B.x, P.x) && inRange(A.y, B.y, P.y);
    }

    /** Auf welcher Seite der durch L1 und L2 definierten Geraden liegt P?
     *
     * @param L1 Punkt 1 der Geraden
     * @param L2 Punkt 2 der Geraden
     * @param X Der fragliche Punkt
     * @return -1 oder-1, wird 0 z�r�ckgeliefet liegt X genau auf der Geraden
     */
    private static int seite(Position L1, Position L2, Position X) {
        return (int)Math.signum((X.y - L1.y) * (L2.x - L1.x) - (L2.y - L1.y) * (X.x - L1.x));
    }

    /** Liegt P innerhalb des durch A, B und C definierten Dreiecks?
     *
     * @param A Punkt 1 des Dreiecks
     * @param B Punkt 2 des Dreiecks
     * @param C Punkt 3 des Dreiecks
     * @param P Der fragliche Punkt
     * @param includeLinie true, wenn Punkte, die  genau auf Begrenzungelinien des Dreiecks liegen, als innerhalb
     * gewertet werden sollen
     * @return true/false
     */
    private static boolean inDreieck(Position A, Position B, Position C, Position P, boolean includeLinie) {
        int s1 = seite(A, P, B);
        int s2 = seite(A, P, C);

        if (s1 == 0) {
            return includeLinie && inLinie(A, B, P);
        }

        if (s2 == 0) {
            return includeLinie && inLinie(A, C, P);
        }

        if (s1 == s2) {
            return false;
        }

        s1 = seite(B, P, A);
        s2 = seite(B, P, C);

        if (s2 == 0) {
            return includeLinie && inLinie(B, C, P);
        }

        return s1 != s2;
    }



    public static boolean inViereck(Position A, Position B, Position C, Position D, Position P) {
        return inDreieck(A, B, C, P, true) || inDreieck(D, B, C, P, true);
    }

    /*
    public static void main(String[] args) {
        Position D = new Position(1, 1);
        Position E = new Position(1, 7);
        Position F = new Position(4, 4);

        check(D, E, F);
        check(E, D, F);
        check(F, D, E);
        check(F, E, D);
        check(E, F, D);
        check(D, F, E);

        check(inDreieck(new Position (1, -2), E, F, new Position(1, 0), true), true);
    }

    public static void check(Position D, Position E, Position F) {
        check(inDreieck(D, E, F, new Position(2, 3), true), true);
        check(inDreieck(D, E, F, new Position(0, 3), true), false);
        check(inDreieck(D, E, F, new Position(4, 3), true), false);
        check(inDreieck(D, E, F, new Position(3, 4), true), true);
        check(inDreieck(D, E, F, new Position(3, 6), true), false);

        check(inDreieck(D, E, F, new Position(1, 4), true), true);
        check(inDreieck(D, E, F, new Position(2, 6), true), true);
        check(inDreieck(D, E, F, new Position(2, 2), true), true);

        check(inDreieck(D, E, F, new Position(1, 4), false), false);
        check(inDreieck(D, E, F, new Position(2, 6), false), false);
        check(inDreieck(D, E, F, new Position(2, 2), false), false);

        check(inDreieck(D, E, F, new Position(1, 8), true), false);
        check(inDreieck(D, E, F, new Position(0, 6), true), false);
        check(inDreieck(D, E, F, new Position(0, 0), true), false);

        check(inDreieck(D, E, F, D, true), true);
        check(inDreieck(D, E, F, E, true), true);
        check(inDreieck(D, E, F, F, true), true);

        check(inDreieck(D, E, F, D, false), false);
        check(inDreieck(D, E, F, E, false), false);
        check(inDreieck(D, E, F, F, false), false);
    }

    public static void check(boolean b1, boolean b2) {
        if (b1 != b2) {
            System.out.println("Aaah");
            System.exit(1);
        }
    }
    */
}
