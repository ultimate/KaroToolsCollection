package de.uobst.repower;

import static de.uobst.karobase.KaroMapConstants.START;
import static de.uobst.karobase.KaroMapConstants.ZIEL;

import java.util.List;
import java.util.stream.IntStream;

import de.uobst.karobase.KaroMapConstants;
import de.uobst.karobase.Position;
import de.uobst.repower.Repower.Params;

public class CheckAction extends R2Action {
    @Override
    R2Map transform(ActionContext context, R2Map map) throws RepowerException {

        List<Position> starts = map.getPositionsByType(START);
        List<Position> ziele = map.getPositionsByType(ZIEL);
        int checkpointBits =
            IntStream.range(1, 9)
                .mapToObj(cp -> KaroMapConstants.cpIndexToKarocode(cp))
                .filter(cp -> !map.getPositionsByType(cp).isEmpty())
                .mapToInt(cp -> KaroMapConstants.getCPBit(cp))
                .reduce((cp1, cp2) -> cp1 | cp2)
                .orElse(0);

        if (starts.isEmpty()) {
            throw new MapNotDrivableException("Fahrbarkeitstest fehlgeschlagen (Keine Startpositionen vorhanden)");
        }

        if (ziele.isEmpty()) {
            throw new MapNotDrivableException("Fahrbarkeitstest fehlgeschlagen (Keine Ziele vorhanden)");
        }

        var ra = map.analyseReachablity(true, false);
        if (!ra.isEverythingReachable(starts.size(), checkpointBits, 1, true)) {
            if (ra.reachedCheckpoints() != checkpointBits) {
                throw new MapNotDrivableException("Fahrbarkeitstest fehlgeschlagen (Checkpoints nicht erreichbar)");
            } else if (ra.reachedStarts() != starts.size()) {
                throw new MapNotDrivableException("Fahrbarkeitstest fehlgeschlagen (Starts h�ngen nicht zusammen)");
            } else {
                throw new MapNotDrivableException("Fahrbarkeitstest fehlgeschlagen" + ra);
            }

        }

        int size = (map.getWidth() + 1) * map.getHeight();
        if ( size > 65536) {
            throw new ResultMapTooLargeException("Karte zu gro� (" + size + " Karos)");
        }
        return map;
    }

    @Override
    boolean isNeutral(Params params) {
        return false;
    }

}
