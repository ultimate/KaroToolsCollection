package de.uobst.repower;

import static de.uobst.base.collection.CollectionUtils.first;
import static de.uobst.base.collection.Lists.removeRandom;
import static de.uobst.karobase.KaroMapConstants.CP_MAX;
import static de.uobst.karobase.KaroMapConstants.CP_MIN;
import static de.uobst.karobase.KaroMapConstants.START;
import static de.uobst.karobase.KaroMapConstants.ZIEL;
import static java.util.Collections.emptyList;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

import de.uobst.base.collection.Lists;
import de.uobst.generator.MapObject;
import de.uobst.generator.Rectangle;
import de.uobst.karobase.KaroMapConstants;
import de.uobst.karobase.Map2KaroMapTranslator;
import de.uobst.repower.R2Map.MapCharacteristics;
import de.uobst.repower.Repower.Params;

public class DistributeAction extends R2Action {

    @Override
    R2Map transform(ActionContext context, R2Map map)
        throws RepowerException {

        redistribute(context, map);
        return map;
    }


    private void redistribute(ActionContext context, R2Map map) throws RepowerException {
        KlumpenSpec startSpec = context.params().klumpenSpecOf(START);
        MapCharacteristics mc = map.getMapCharacteristics();

        if (startSpec.isEmpty(mc.multiklumpen(START))) {
            throw new RepowerException("Karte enth�lt keine Startpunkte, bitte Anzahl Spieler manuell setzen");
        }

        dist2(context, map, mc, new byte[]{START});

        byte[] karocodes = new byte[CP_MAX - CP_MIN + 1];
        karocodes[0] = ZIEL;

        KlumpenSpec zielSpec = context.params().klumpenSpecOf(ZIEL);
        mc = map.getMapCharacteristics();
        if (zielSpec.isEmpty(mc.multiklumpen(ZIEL))) {
            throw new RepowerException("Karte enth�lt keine Ziele, bitte Anzahl Ziele manuell setzen");
        }

        for (byte i = CP_MIN + 1; i <= CP_MAX; i++) {
            karocodes[i - CP_MIN] = i;
        }
        dist2(context, map, mc, karocodes);
    }

    private static void dist2(ActionContext context, R2Map map, MapCharacteristics mc, byte[] karocodes) throws RepowerException {
        List<List<D2>> distributors = new ArrayList<>();
        for (byte karocode : karocodes) {

            var result = D2.get(
                karocode,
                context,
                mc.multiklumpen(karocode));

            if (!result.isEmpty()) {
                result.forEach(d2 -> d2.init(map));
                distributors.add(result);
            }
        }

        int expectedCheckpoints = 0;
        boolean zieleGesetzt = !map.getPositionsByType(ZIEL).isEmpty();

        int rectcount = (int)distributors.stream().flatMap(list -> list.stream()).filter(d -> d.usesRectangle()).count();
        var rects = getRectangles(rectcount, map, context.random());

        int startCounts = map.getPositionsByType(START).size();

        for (List<D2> dlist : distributors) {

            int tries = Repower.MAX_TRIES;
            boolean raOk;
            boolean randomPositionsCreated = false;
            byte karocode = first(dlist).karocode;

            do {
                List<Rectangle> usedRects = new ArrayList<>();
                List<MapObject> mapObjects = new ArrayList<>();;
                int sum = 0;
                for (D2 d : dlist) {
                    Rectangle rect = d.usesRectangle() ? Lists.removeRandom(rects, context.random()) : null;
                    MapObject m = d.distribute(map, rect);
                    map.add(m);
                    randomPositionsCreated |= d.createsRandomPositions();
                    if (rect != null) {
                        usedRects.add(rect);
                    }
                    mapObjects.add(m);
                    sum += d.getCount();
                }

                switch(karocode) {
                case ZIEL -> zieleGesetzt = true;
                case START -> startCounts = sum;
                default ->  {
                        if (sum > 0) {
                            expectedCheckpoints |= KaroMapConstants.getCPBit(karocode);
                        }
                    }
                }

                var ra = map.analyseReachablity(true, false);
                raOk = ra.isEverythingReachable(startCounts, expectedCheckpoints, 1, zieleGesetzt);
                if (!raOk) {
                    mapObjects.forEach(map::undo);
                    if (karocode == START) {
                        startCounts = 0;
                    }
                    rects.addAll(usedRects);
                }


            } while (!raOk
                && randomPositionsCreated
                && --tries > 0);

            if (!raOk) {
                throw new RepowerException("Kann Positionen f�r Typ "
                    + Map2KaroMapTranslator.translateToDidiCode(karocode)
                    + " nicht finden");
            }

        }
    }

    private static List<Rectangle> getRectangles(int rectCount, R2Map map, Random random) {
        if (rectCount == 0) {
            return emptyList();
        }

        var rectangles = map.getRandomRectangles(Math.min(rectCount,  10), random);
        var result = new ArrayList<Rectangle>();
        for (int i = rectangles.size(); i != 0; i--) {
            Rectangle r = removeRandom(rectangles,  random);
            int count = rectCount / i;
            IntStream.range(0,  count).forEach(n ->result.add(r));
            rectCount -= count;
        }
        return result;
    }


    @Override
    boolean isNeutral(Params params) {
        return params.checkpoints().isUnspecified()
            && !params.redistributeCPs()
            && !params.redistributeStarts()
            && !params.redistributeFinishs()
            && params.players().isUnspecified()
            && params.ziele().isUnspecified();
    }

}
