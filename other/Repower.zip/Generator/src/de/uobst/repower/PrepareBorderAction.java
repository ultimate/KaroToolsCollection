package de.uobst.repower;

import de.uobst.repower.Repower.Params;

public class PrepareBorderAction extends R2Action {

    @Override
    R2Map transform(ActionContext context, R2Map map) {
        byte bg = Repower.UNSPECIFIED_KAROCODE;

        if (!map.isSolidRow(0)) {
            map.addRow(0, bg);
        }

        if (!map.isSolidRow(map.getHeight() - 1)) {
            map.addRow(map.getHeight(), bg);
        }

        if (!map.isSolidColumn(0)) {
            map.addColumn(0, bg);
        }

        if (!map.isSolidColumn(map.getWidth() - 1)) {
            map.addColumn(map.getWidth(), bg);
        }
        return map;
    }

    @Override
    boolean isNeutral(Params params) {
        return false;
    }

}
