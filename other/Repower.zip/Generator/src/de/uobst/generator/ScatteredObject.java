package de.uobst.generator;

import static de.uobst.base.collection.Lists.removeRandom;

import java.util.Collection;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import de.uobst.karobase.Position;

public class ScatteredObject extends MapObject {
    private List<Position> positions = null;

    public ScatteredObject(int count, Random random, List<Position> availablePositions, byte karocode) {
        super(karocode);

        positions = IntStream.range(0,  count)
            .mapToObj(i -> removeRandom(availablePositions, random))
            .collect(Collectors.toList()); // Nicht toList() damit die Positionen modifizierbar bleiben
    }

    @Override
    public Collection<Position> getPositions() {
        return positions;
    }

    public void addPositions(Collection<Position> positionsToAdd) {
        positions.addAll(positionsToAdd);
    }
}
