package de.uobst.generator;

import java.util.Collection;
import java.util.Collections;

import de.uobst.karobase.Position;

public class EmptyMapObject extends MapObject {

    public EmptyMapObject() {
        super((byte)0);
    }

    @Override
    public Collection<Position> getPositions() {
        return Collections.emptyList();
    }

    @Override
    protected void saveUndoPosition(Position p, byte oldKaroCode) {
        throw new UnsupportedOperationException();
    }
}
