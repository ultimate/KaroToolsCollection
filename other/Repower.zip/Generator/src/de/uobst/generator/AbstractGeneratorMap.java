package de.uobst.generator;

import static de.uobst.base.collection.Lists.removeRandom;
import static de.uobst.karobase.KaroMapConstants.getCPBit;
import static java.util.stream.IntStream.range;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.eclipse.jdt.annotation.NonNull;

import de.uobst.karobase.KaroBaseMap;
import de.uobst.karobase.KaroMapConstants;
import de.uobst.karobase.Position;

public abstract class AbstractGeneratorMap extends KaroBaseMap {

    public AbstractGeneratorMap(KaroBaseMap source) {
        super(source);
    }

    public AbstractGeneratorMap(int height, int width, byte karocode) {
        super(height, width, karocode);
    }

    /** Ergebnis der Erreichbarkeitsanalyse
     *
     */
    public static class ReachableAnalysis {
        final boolean reached[][];
        final Set<Position> startsReached = new HashSet<>();
        @SuppressWarnings("unchecked")
        final Set<Position>[] cpPositions = new Set[KaroMapConstants.CP_MAX - KaroMapConstants.CP_MIN + 1];
        int checkpointsReached; // Bitmaske
        boolean finishReached;
        int reachablePositions;

        public ReachableAnalysis(int width, int height) {
            reached = new boolean[height][width];
            IntStream.range(0,  cpPositions.length).forEach(i -> cpPositions[i] = new HashSet<>());
        }

        public int getReachablePositions() {
            return reachablePositions;
        }

        public boolean isEverythingReachable(int expectedStarts, int expectedCheckpoints, int mincpcount) {
            return isEverythingReachable(expectedStarts, expectedCheckpoints, mincpcount, true);
        }

        public boolean isEverythingReachable(int expectedStarts, int expectedCheckpoints, int mincpcount, boolean expectFinishs) {
            return expectedStarts== startsReached.size()
                && (expectedCheckpoints & checkpointsReached) == expectedCheckpoints
                && (finishReached || !expectFinishs)
                // Kein Checkpoint hat weniger als mincpcount erreichbare Checkpoints
                && !IntStream.range(0, cpPositions.length)
                    .filter(cpi -> (expectedCheckpoints & (1 << cpi)) != 0)
                    .anyMatch(cpi -> cpPositions[cpi].size() < mincpcount);
        }

        @Override
        public String toString() {
            return String.format("%d starts reached, %s checkpoints reached, finish reached: %s",
                startsReached.size(),
                KaroMapConstants.getCheckpointString(checkpointsReached),
                finishReached);
        }

        @Override
        public boolean equals(Object obj) {
            return obj instanceof ReachableAnalysis ra
                && startsReached.equals(ra.startsReached)
                && Arrays.equals(cpPositions, ra.cpPositions)
                && checkpointsReached == ra.checkpointsReached
                && finishReached == ra.finishReached
                && reachablePositions == ra.reachablePositions;
        }

        public int reachedCheckpoints() {
            return checkpointsReached;
        }

        public int reachedStarts() {
            return startsReached.size();
        }

        public void merge(ReachableAnalysis ra) {
            for (int y = reached.length - 1; y >= 0; y--) {
                for (int x = reached[y].length - 1; x >= 0; x--) {
                    reached[y][x] |= ra.reached[y][x];
                }
            }
            startsReached.addAll(ra.startsReached);
            IntStream.range(0,  cpPositions.length).forEach(i -> cpPositions[i].addAll(ra.cpPositions[i]));
            checkpointsReached &= ra.checkpointsReached;
            finishReached &= ra.finishReached;
            reachablePositions += ra.reachablePositions;

        }
    }


    public ReachableAnalysis analyseReachablity(boolean diagonalAllowed, boolean expectConnectedStarts) {
        ReachableAnalysis result = null;

        List<Position> starts = getPositionsByType(KaroMapConstants.START);
        if (starts.isEmpty()) {
            return new ReachableAnalysis(getWidth(), getHeight());
        }

        do {
            ReachableAnalysis ra = new ReachableAnalysis(getWidth(), getHeight());
            Position start = starts.get(0);
            reach4(ra, (short)start.x, (short)start.y, diagonalAllowed);

            int oldStartCount = starts.size();
            starts.removeAll(ra.startsReached);

            if (result == null) {
                result = ra;
            } else {
                result.merge(ra);
            }

            if (starts.size() >= oldStartCount) {
                // kein weiterer Start gefunden, hier ist was total schief gelaufen
                break;
            }

        } while(!expectConnectedStarts && !starts.isEmpty());

        return result;
    }



    /** Pr�ft die Erreichbar keit der Starts, Ziele und Checkpoints.
     * Iterative Variante. 4. Inkarnation.
     * Entspricht dem rekursiven Algorithmus:
     * void reach(ReachableAnalysis ra, short x, short y) {
     *      if (abbruch(ra, x, y)) {
     *          return;
     *      }
     *
     *      doit(ra, x, y);
     *      reach(ra, x, y-1);
     *      reach(ra, x - 1, y);
     *      reach(ra, x + 1, y);
     *      reach(ra, x, y + 1);
     *}
     *
     * Die rekursive Variante ist viel lesbarar und eleganter, aber leider wird der Stack dadurch zu gro�
     * @param ra
     * @param x
     * @param y
     */
    private void reach4(ReachableAnalysis ra, short x, short y, boolean diagonalAllowed) {
        short[] stack = new short[getWidth() * getHeight() * 3];
        int framepointer = 0;
        int stepcount = diagonalAllowed ? 7 : 3;

        for(;;) {
            while(abbruch(ra, x, y)) {
                short nextStep = 0;
                while(framepointer > 0 && (nextStep = stack[framepointer - 1]++) == stepcount) {
                    // pop from stack
                    framepointer -= 3;
                }
                if (framepointer <= 0) {
                    return;
                }

               x = stack[framepointer - 3];
               y = stack[framepointer - 2];
               switch(nextStep) {
                   case 0 -> x++;
                   case 1 -> x--;
                   case 2 -> y++;
                   case 3 -> {x++; y++; }
                   case 4 -> {x--; y++; }
                   case 5 -> {x++; y--; }
                   case 6 -> {x--; y--; }

                   default -> throw new IllegalStateException();
               }
            }

            doit(ra, x, y);
            stack[framepointer++] = x;
            stack[framepointer++] = y;
            stack[framepointer++] = 0; // Next step: 0
            y--;
        }
    }

    private boolean abbruch(ReachableAnalysis ra, int x, int y) {
        if (!isValidPosition(x, y)) {
            return true;
        }

        if (ra.reached[y][x]) {
            return true;
        }

        return !isDriveable(x, y);
    }

    private void doit(ReachableAnalysis ra, int x, int y) {
        byte karocode = get(x, y);

        if (karocode == KaroMapConstants.START) {
            ra.startsReached.add(new Position(x, y));
        } else if (karocode == KaroMapConstants.ZIEL) {
            ra.finishReached = true;
        } else if (KaroMapConstants.isCP(karocode)) {
            int idx = KaroMapConstants.karocodeToCpIndex(karocode);
            ra.cpPositions[idx].add(new Position(x, y));
            ra.checkpointsReached |= getCPBit(karocode);
        }

        ra.reached[y][x] = true;
        ra.reachablePositions++;
    }


    private byte getRandomKaro(Map<Byte, Integer> karocodes, int r) {
        for (var it = karocodes.entrySet().iterator(); it.hasNext(); ) {
            var entry = it.next();
            if ((r -= entry.getValue()) < 0) {
                return entry.getKey();
            }
        }
        throw new IllegalArgumentException("r: " + r);
    }

    public void fillRandom(Map<Byte, Integer> karocodes, Random random) {
        int totalFrequency =  karocodes.values().stream().mapToInt(i -> i).sum();
        int width = getWidth();
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < width; j++) {
                map[i][j] = getRandomKaro(karocodes, random.nextInt(totalFrequency));
            }
        }
    }

    public byte[][] getCode() {
        return map;
    }


    public void setRow(int row, byte karocode) {
        Arrays.fill(map[row],karocode);
        notifyChanged();
    }

    public void setColumn(int column, byte karocode) {
        range(0, getHeight()).forEach(r -> set(column, r, karocode));
        notifyChanged();;
    }

    public void addRow(int row, byte karocode) {
        byte[][] newmap = new byte[getHeight() + 1][];
        System.arraycopy(map, 0, newmap, 0, row);
        System.arraycopy(map, row, newmap, row + 1, map.length - row);
        newmap[row] = new byte[getWidth()];
        Arrays.fill(newmap[row], karocode);
        map = newmap;
        notifyChanged();
    }

    public void addColumn(int column, byte karocode) {
        int width = getWidth();
        for (int i = 0; i < map.length; i++) {
            byte[] newrow = new byte[width + 1];
            System.arraycopy(map[i], 0, newrow, 0, column);
            System.arraycopy(map[i], column, newrow, column + 1, width - column);
            newrow[column] = karocode;
            map[i] = newrow;
        }
        notifyChanged();;
    }

    /** Entfernt eine Zeile, wenn sie ausschlie�lich aus Karos der Art karocode besteht
     */
    public boolean removeRowIf(int row, byte karocode) {
        if (IntStream.range(0,  getWidth()).anyMatch(x -> get(x, row) != karocode)) {
            return false;
        }

        byte[][] newrows = new byte[getHeight() - 1][];
        System.arraycopy(map, 0, newrows, 0, row);
        System.arraycopy(map, row + 1, newrows, row, getHeight() - row - 1);
        map = newrows;
        notifyChanged();
        return true;
    }

    /** Entfernt eine Spalte, wenn sie ausschlie�lich aus Karos der Art karocode besteht
     */
    public boolean removeColumnIf(int column, byte karocode) {
        if (IntStream.range(0,  getHeight()).anyMatch(y -> get(column, y) != karocode)) {
            return false;
        }

        int w = getWidth();

        for (int y = getHeight() - 1; y >= 0; y--) {
            byte[] newrow = new byte[w - 1];
            System.arraycopy(map[y], 0, newrow, 0, column);
            System.arraycopy(map[y], column + 1, newrow, column, w - column - 1);
            map[y] = newrow;
        }

        notifyChanged();
        return true;
    }


    public void set(@NonNull Position p, byte karocode) {
        super.set(p.x,  p.y,  karocode);
    }

    /** Adds the given MapObject to the map. No checks are performed. If the mapObject extends over the border of this map
     * only the valid karos are used. Once added, the object can be removed with {@link #undo(MapObject)}
     * @param obj The object to add
     * @param karocode the karocode to be used for the karos.
     */
    public void add(@NonNull MapObject obj) {
        obj.getPositions().stream().filter(this::isValidPosition).forEach(p -> {
            obj.saveUndoPosition(p, get(p));
            set(p, obj.karocode);
        });
    }

    /** add the object only if fits on the map in total and if the object does not cover unexpected karos
     *
     * @param obj The object to add
     * @param expectedKaroCode Add the object only if all position of the current map have this karocode
     * @return true if the object was added to the map
     */
    public boolean addIfValid(@NonNull MapObject obj, Set<Byte> expectedkaroCodes) {
        if (!obj.getPositions().stream().allMatch(p -> isValidPosition(p) && expectedkaroCodes.contains(get(p)))) {
            return false;
        }

        add(obj);
        return true;
    }

    public void undo(@NonNull MapObject obj) {
        obj.getUndoPositions().entrySet().stream().forEach(e -> set(e.getKey(), e.getValue()));
    }


    public void copyFrom(KaroBaseMap source, Rectangle sourceRect, Position target, boolean keepDriveables) {
        for (int y = sourceRect.height() - 1; y >= 0; y--) {
            for (int x = sourceRect.width() - 1; x >= 0; x--) {
                if (!keepDriveables || !isDriveable(target.x + x, target.y + y)) {
                    set(target.x + x, target.y + y, source.get(sourceRect.x() + x, sourceRect.y() + y));
                }
            }
        }
    }

    public List<Position> getDrivablesInColumn(int column) {
        return IntStream.range(0,  getHeight())
            .filter(row -> isDriveable(column,  row))
            .mapToObj(row -> new Position(column, row))
            .collect(Collectors.toList());
    }

    public Rectangle getRectangle() {
        return new Rectangle(1, 1, getWidth() - 2, getHeight() - 2);
    }

    public List<Rectangle> getRandomRectangles(int count, Random random) {
        enum Orientation {
            HORIZONTAL, VERTICAL

        };

        List<Rectangle> rectangles = new ArrayList<>();

        if (count == 0) {
            return Collections.emptyList();
        }

        // +1 weil Finish auch in einem eigenen Rechteck generiert wird
        int[] rectDist = switch(count) {
            case 1 -> new int[]{1};
            case 2 -> new int[]{2};
            case 3 -> new int[]{2, 1};
            case 4 -> new int[]{2, 2};
            case 5 -> new int[]{3, 2};
            case 6 -> new int[]{3, 3};
            case 7 -> new int[]{3, 2, 3};
            case 8 -> new int[]{3, 3, 2};
            case 9 -> new int[]{3, 3, 3};
            case 10 -> new int[]{4, 3, 3};
            default ->  throw new IllegalArgumentException("Unexpected number : " + count);
        };

        Rectangle mapRect = getRectangle();

        Orientation orientation = getWidth() > getHeight() ? Orientation.HORIZONTAL : Orientation.VERTICAL;

        List<Integer> scounts = Arrays.stream(rectDist).boxed().collect(Collectors.toList());

        while(scounts.size() > 0) {
            int scount = removeRandom(scounts, random);

            for (int j = 0; j < scount; j++) {
                int x, y, width, height;

                if (orientation == Orientation.HORIZONTAL) {
                    x = j;
                    width = scount;
                    y = scounts.size();
                    height = rectDist.length;
                } else {
                    y = j;
                    height = scount;
                    x = scounts.size();
                    width = rectDist.length;
                }

                int rx = mapRect.width() * x / width;
                int rwidth = getWidth() * (x + 1) / width - rx;
                int ry = mapRect.height() * y / height;
                int rheight = getHeight() * (y + 1) / height - ry;

                rectangles.add(new Rectangle(rx + 1 + mapRect.x(), ry + 1 + mapRect.y(), rwidth - 2, rheight - 2));
            }
        }

        return rectangles;
    }

}
