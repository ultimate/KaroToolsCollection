package de.uobst.generator;

import static de.uobst.base.collection.Lists.getRandom;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import de.uobst.karobase.Map2KaroMapTranslator;
import de.uobst.karobase.Position;
import de.uobst.repower.RepowerException;

public class ConstrainedGnubbel extends MapObject {

    private static final int MAX_GNUBBEL_TRIES = 20;

    private List<Position> positions = null;

    public ConstrainedGnubbel(int count, Random random, List<Position> availablePositions, List<Position> present, byte karocode)
        throws RepowerException {

        super(karocode);

        computePositions(random, count, availablePositions, present);
        if (positions == null) {
            throw new RepowerException("Can't find block of positions for " +Map2KaroMapTranslator.translateToDidiCode(karocode));
        }
    }


    /**
     *
     * @param random
     * @param count Anzahl, die hinzugef�gt werden soll
     * @param availablePositions
     * @param present
     */

    private void computePositions(Random random, int count, List<Position> availablePositions, List<Position> present) {

        if (count == 0) {
            positions = new ArrayList<>();
            return;
        }

        Set<Position> availableSet = new HashSet<>(availablePositions);
        List<Position> gnubbel;
        int maxtries = MAX_GNUBBEL_TRIES;
        int added;

        do {
            added = 0;
            gnubbel = new ArrayList<>(present);
            if (gnubbel.size() == 0) {
                gnubbel.add(getRandom(availablePositions, random));
                added = 1;
            }

            int oldsize;
            int startPos = 0;
            do {
                oldsize = gnubbel.size();
                findNewPositions(gnubbel, startPos, availableSet, random, count - added);
                startPos = oldsize;
                added += gnubbel.size() - oldsize;

                // Solange machen wie neue Positionen gefunden werden.
                // Wenn erforderliche Menge erreicht ist, ist gnubbel.size = oldsize und das Ganze terminiert.
            } while(gnubbel.size() > oldsize && added < count);

            // Falls present.IsEmpty, dann haben wir den Startpunkt perm Zufall bestimmt, dann mochmal wiederholen
            // (maxtritries mal). Falls !present.isEmpty, dann nur einmal machen, wenn das nicht alles liefert, dann geht es nicht
        } while(present.isEmpty() && maxtries-- > 0 && added < count);

        if (added == count) {
            gnubbel.removeAll(present);
            positions = gnubbel;
        }
    }

    private void findNewPositions(List<Position> gnubbel, int startPos,
        Set<Position> availablePositions, Random random, final int requestedPositions) {

        int i = 0;
        List<Position> seeds = new ArrayList<Position>(gnubbel.subList(startPos, gnubbel.size()));
        int r = random.nextInt(seeds.size());
        int found = 0;

        while(found < requestedPositions && !seeds.isEmpty()) {
            Position seed = seeds.get((r + i++) % seeds.size());
            Position next = getNext(seed, random, availablePositions, gnubbel);
            if (next != null) {
                gnubbel.add(next);
                found ++;
            } else {
                seeds.remove(seed);
                i--;
            }
        }

    }


    private Position getNext(Position p, Random random, Set<Position> availablePositions, List<Position> gnubbel) {
        int dir = random.nextInt(4);
        int i = 0;
        Position next = null;
        do {
            next = new Position(p);
            switch((dir + i) % 4) {
                case 0 -> next.y--;
                case 1 -> next.x--;
                case 2 -> next.y++;
                case 3 -> next.x++;
            }
        } while((!availablePositions.contains(next) || gnubbel.contains(next)) && ++i < 4);
        return i == 4 ? null : next;
    }


    @Override
    public Collection<Position> getPositions() {
        return positions;
    }

    public void addPositions(Collection<Position> positions) {
        this.positions.addAll(positions);
    }
}
