package de.uobst.generator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.function.Function;
import java.util.stream.Collectors;

import de.uobst.karobase.Map2KaroMapTranslator;

public class AbstractGenerator {

    public record Frequence (byte karocode, int frequence){}

    protected static Map<Byte, List<Frequence>> parseFrequenceKarolist(String karolist, String allowedKaros, boolean emptyAllowed,
        int defaultFrequency, int minimumFrequency) {
            return parseKarolist(karolist, allowedKaros, emptyAllowed,
                valueString -> {
                        List<Frequence> result = new ArrayList<>();

                        for (int i = 0; i < valueString.length(); i++) {
                            char c = valueString.charAt(i);
                            if (Map2KaroMapTranslator.isValidDidiCode(c)) {
                                byte karocode = Map2KaroMapTranslator.translateToInternal(c);
                                int frequency = defaultFrequency;
                                if (i + 2 < valueString.length() && valueString.charAt(i + 1) == '*') {
                                    int sidx = i += 2;
                                    while(Character.isDigit(valueString.charAt(i)) && ++i < valueString.length()) {}
                                    try {
                                        frequency = Integer.max(Integer.parseInt(valueString.substring(sidx, i)), minimumFrequency);
                                    } catch (NumberFormatException ex) {
                                        // in diesem Fall bleibt es bei Default frequency
                                    }
                                    i--;
                                }
                                result.add(new Frequence(karocode, frequency));
                            }
                        }
                        return result.isEmpty() ? null: result;
                });
        }

    protected static Map<Byte, Integer> parseKarolist(String karolist, String allowedKaros, boolean emptyAllowed,
        int def, int minimum) {
        return parseKarolist(karolist, allowedKaros, emptyAllowed,
            valueString -> {
                if (valueString.isBlank()) {
                    return def;
                }
                int value;
                try {
                    value = Integer.parseInt(valueString);
                } catch (NumberFormatException ex) {
                    value = def;
                }
                return Math.max(minimum,  value);
            });
    }

    /** Parst eine Karoliste. Eine Karoliste ist eine durch Komma getrennte Liste von
     * Mappings. Ein Mapping ist wiederum eine Liste von Karocodes (Didi Codes, nicht getrennt, direkt hintereinander) auf einen
     * Wert des Typs V. Werteliste und Wert sind durch : getrennt (was impliziert, dass weder  Komma noch Doppelpunkt
     * Teil einer Karocode Liste bzw. Werten sein k�nnen.
     * Beispiel f�r ein Mapping w�re XYZ:abc, wobei abc der Wert w�re (was auch imm er das f�r ein Wert sein soll
     * und XYZ die Karocodes.
     *
     * @param <V> Der Typ des Wertes eines jeden Mappimngs
     * @param karolist Die Stringrepr�sentation der Karoliste
     * @param allowedKaros Die erlaubten Karoscodes (Didi Codes), die auf die Werte abgebildes werden
     * @param emptyAllowed Gibt an, ob eine leere karoliste erlaubt ist. Falls nicht, und es wird aber
     * eine leere Liste �bergeben, wird ein Mapping des ersten erlaubten Karocodes auf einen leeren
     * Wert zur�ckgeliefert.
     * @param valueSupplier Die Funktion, die einben Wert aus der Stringrepr�sentation
     * in den erwarteten Wert V wandeln kann.
     * @return Eine Map, die die einzelnen Karocodes auf die Werte abbildet
     */
    public static <V> Map<Byte, V> parseKarolist(String karolist, String allowedKaros, boolean emptyAllowed,
        Function<String, V> valueSupplier) {

        Map<Byte, V> karoMap = new HashMap<>();

        for (StringTokenizer t = new StringTokenizer(karolist.replaceAll(" ", ""), ","); t.hasMoreElements(); ) {
            String token = t.nextToken();
            if (token.isEmpty()) {
                continue;
            }

            List<Byte> karocodes = new ArrayList<>();
            int idx = 0;
            do {
                char didiKaroChar = token.charAt(idx);
                if (allowedKaros.indexOf(didiKaroChar) != -1) {
                    byte karocode =
                        Map2KaroMapTranslator.isValidDidiCode(didiKaroChar)
                            ? Map2KaroMapTranslator.translateToInternal(didiKaroChar)
                            : (byte) didiKaroChar;
                    karocodes.add(karocode);
                }
            } while(++idx < token.length() && token.charAt(idx) != ':');

            String valueString = "";

            if (idx < token.length() && token.charAt(idx) == ':') {
                valueString = token.substring(idx + 1);
            }

            V value = valueSupplier.apply(valueString);
            if (value != null) {
                karocodes.forEach(b -> karoMap.put(b,  value));
            }
        }
        if (karoMap.isEmpty() && !emptyAllowed) {
            karoMap.put(Map2KaroMapTranslator.translateToInternal(allowedKaros.charAt(0)),  valueSupplier.apply(""));
        }
        return karoMap;
    }

    protected static String correctkaroList1(String spec, String allowedKaros, String defaultSpec,
        int defaultFrequency, int minimumFrequency) {
        spec = parseKarolist(spec, allowedKaros, true, defaultFrequency, minimumFrequency)
            .entrySet()
            .stream()
            .map(e -> Map2KaroMapTranslator.translateToDidiCode(e.getKey()) + (e.getValue() != defaultFrequency ? ":" + e.getValue(): ""))
            .collect(Collectors.joining(","));

        return spec.isEmpty() ? defaultSpec : spec;
    }


}
