package de.uobst.generator;

import de.uobst.karobase.Position;

public record Rectangle(int x, int y, int width, int height) {

    public boolean contains(Position p) {
        return p.x >= x && p.x < x + width && p.y >= y && p.y < y + height;
    }
}
