package de.uobst.generator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;

import de.uobst.karobase.Position;

public class Gnubbel extends MapObject {

    private List<Position> positions = new ArrayList<>();

    public Gnubbel(Position center, int karocount, Random random, byte karocode) {
        super(karocode);

        int l = (int)Math.sqrt(karocount);
        int x = center.x - l / 2;
        int y = center.y - l / 2;
        int n = 0;

        for (int i = 0; i < l; i++) {
            for (int j = 0; j < l; j++) {
                positions.add(new Position(x + i, y + j));
                n++;
            }
        }

        int lx = l;
        int ly = l;

        while (n < karocount) {
            int ax, ay, d;

            switch(random.nextInt(4)) {
            case 0:
                x--;
                ax = x;
                ay = y;
                d = 0;
                break;

            case 1:
                y--;
                ax = x;
                ay = y;
                d = 1;
                break;

            case 2:
                ax = x + lx;
                ay = y;
                d = 0;
                break;

            default:
                ax = x;
                ay = y + ly;
                d = 1;
                break;
            }

            lx += (1 - d);
            ly += d;

            while(ax < x + lx && ay < y + ly && n < karocount) {
                positions.add(new Position(ax, ay));
                ax += d;
                ay += 1 - d;
                n++;
            }
        }
    }

    @Override
    public Collection<Position> getPositions() {
        return positions;
    }

}
