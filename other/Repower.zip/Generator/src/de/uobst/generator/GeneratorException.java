package de.uobst.generator;

@SuppressWarnings("serial")
public class GeneratorException extends Exception {

    public GeneratorException(Throwable cause) {
        super(cause);

    }

    public GeneratorException(String message) {
        super(message);

    }

}
