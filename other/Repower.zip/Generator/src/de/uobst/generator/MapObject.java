package de.uobst.generator;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import de.uobst.karobase.Position;

public abstract class MapObject {
    private Map<Position, Byte> undoInfos = new HashMap<>();

    public final byte karocode;

    public abstract Collection<Position> getPositions();

    protected MapObject(byte karocode) {
        this.karocode = karocode;
    }

    protected void saveUndoPosition(Position p, byte oldKaroCode) {
        undoInfos.put(p, oldKaroCode);
    }

    Map<Position, Byte> getUndoPositions() {
        return undoInfos;
    }

}
