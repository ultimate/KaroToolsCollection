package de.uobst.generator;

import static de.uobst.base.Range.between;
import static de.uobst.generator.Bresenham.createPositions;
import static java.lang.Math.abs;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import de.uobst.base.collection.ListList;
import de.uobst.base.collection.RevertingList;
import de.uobst.karobase.Position;

public class Bar extends MapObject{

    private Set<Position> positions = new HashSet<>();

    public Bar(Position start, Position end, int thickness, byte karocode) {
        super(karocode);

        if (thickness == 1) {
            positions.addAll(createPositions(start,  end));
            return;
        }

        double theta = Math.atan2(end.y - start.y, end.x - start.x) + Math.PI / 2;
        double tx = thickness * Math.cos(theta) / 2;
        double ty = thickness * Math.sin(theta) / 2;

        Position st1 = new Position((int)Math.round(start.x + tx), (int)Math.round(start.y + ty));
        Position st2 = new Position((int)Math.round(start.x - tx), (int)Math.round(start.y - ty));
        Position se1 = new Position((int)Math.round(end.x + tx), (int)Math.round(end.y + ty));
        Position se2 = new Position((int)Math.round(end.x - tx), (int)Math.round(end.y - ty));

        var l1 = createPositions(st1,  st2);
        var l2  = createPositions(se1,  se2);
        var l3 = createPositions(st1,  se1);
        var l4 = createPositions(st2,  se2);

        List<Position> f1;
        List<Position> f2;
        boolean h;
        if (((h = (abs(end.x - start.x) > abs(end.y - start.y)))
            && between(st1.x, st2.x, se1.x))
            || (!h && between(st1.y, st2.y, se1.y))) {

            f1 = new ListList<>(l4, new RevertingList<>(l2));
            f2 = new ListList<>(new RevertingList<>(l1), l3);
        } else {
            f1 = new ListList<>(l1, l4);
            f2 = new ListList<>(l3, l2);
        }
        if (h) {
            fillVertical(f1, f2);
        } else {
            fillHorizontal(f1, f2);
        }

        positions.addAll(l1);
        positions.addAll(l2);
        positions.addAll(l3);
        positions.addAll(l4);
    }


    private void fillVertical(List<Position> l1, List<Position> l2) {
        int lastx = Integer.MIN_VALUE;
        int idx2 = -1;

        for (Position p : l1) {
            if (p.x == lastx) {
                continue;
            }

            Position p2;
            while((p2 = l2.get(++idx2)).x != p.x);

            int dy = Integer.signum(p2.y - p.y);
            if (dy == 0)  {
                continue;
            }

            for (int y = p.y + dy; y != p2.y; y += dy) {
                positions.add(new Position(p.x, y));
            }
            lastx = p.x;
        }
    }

    private void fillHorizontal(List<Position> l1, List<Position> l2) {
        int lasty = Integer.MIN_VALUE;
        int idx2 = -1;

        for (Position p : l1) {
            if (p.y == lasty) {
                continue;
            }

            Position p2;
            while((p2 = l2.get(++idx2)).y != p.y);

            int dx = Integer.signum(p2.x - p.x);
            for (int x = p.x; x != p2.x; x += dx) {
                positions.add(new Position(x, p.y));
            }
            lasty = p.y;
        }
    }

    @Override
    public Collection<Position> getPositions() {
        return positions;
    }

}
