/*
 * Created on Apr 9, 2004
 *
 */
package de.uobst.karobase;

import static de.uobst.karobase.KaroMapConstants.START;
import static de.uobst.karobase.KaroMapConstants.ZIEL;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

/** Base readonly implementation of a Karopapier map.
 * Support for modifying this map is only for subclasses
 * @author ulli
 */
public class KaroBaseMap  {

    // Field with the codes of all karos of this map
    protected byte[][] map;

    // Checkpoint Bitfield
    private short checkpoints = -1;

    public KaroBaseMap(byte[][]data) {
        this.map = data;
    }

    public KaroBaseMap(int height, int width, byte karocode) {
        map = new byte[height][width];
        for (byte[] line: this.map) {
            Arrays.fill(line, karocode);
        }
    }

    public KaroBaseMap(KaroBaseMap source) {
        this(cloneMap(source.map));
    }

    private static byte[][] cloneMap(byte[][] source) {
        byte[][] m  = new byte[source.length][];

        for (int i = 0; i < source.length; i++) {
            m[i] = source[i].clone();
        }
        return m;
    }

    /** Calculates the checkpoint Bitfield of checkpoints in this map
     */
    private final void computeCheckpoints() {
        short cp = 0;
        int width = getWidth();
        int height = getHeight();

        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                byte b = map[i][j];
                cp |= KaroMapConstants.getCPBit(b);
            }
        }
        this.checkpoints = cp;
    }

    public int getWidth() {
        return map[0].length;
    }

    public int getHeight() {
        return map.length;
    }

    /** Returns all positions of the requested type in this map
     *
     * @param type The requested Type, see {@link KaroMapConstants}
     * @return List of Positions, never null
     */
    public final List<Position> getPositionsByType(final byte type) {
        List<Position> result = new ArrayList<Position>();

        for (int y = 0; y < getHeight(); y++) {
            final int w = getWidth();
            for (int x = 0; x < w; x++) {
                if (get(x, y) == type) {
                    result.add(new Position(x, y));
                }
            }
        }
        return result;
    }

    public final Map<Byte, List<Position>> getPositionsByType(final byte[] types) {
        boolean[] karocodes = new boolean[127];
        IntStream.range(0,  types.length).forEach(i -> karocodes[types[i]] = true);
        Map<Byte, List<Position>> result = new HashMap<>();

        for (int y = 0; y < getHeight(); y++) {
            final int w = getWidth();
            for (int x = 0; x < w; x++) {
                byte karocode;
                if (karocodes[karocode = get(x, y)]) {
                    List<Position> l = result.get(karocode);
                    if (l == null) {
                        l = new ArrayList<>();
                        result.put(karocode,  l);
                    }
                    l.add(new Position(x, y));
                }
            }
        }
        return result;
    }

    public final boolean isValidPosition(Position p) {
        return isValidPosition(p.x, p.y);
    }

    public final boolean isValidPosition(int x, int y) {
        return x >= 0 && x < getWidth() && y >= 0 && y < getHeight();
    }

    public final boolean isValidZiel(Position pos) {
        return isValidPosition(pos) && get(pos) == ZIEL;
    }

    public final boolean isValidRasen(Position p) {
        return isValidPosition(p) && !isDriveable(p.x, p.y);
    }

    public final boolean isStart(Position p) {
        return isValidPosition(p) && get(p) == START;
    }

    public final boolean isCP(int x, int y) {
        return KaroMapConstants.isCP(get(x, y));
    }

    protected void notifyChanged() {
        checkpoints = -1;
    }

    /**
     * @return Checkpoint Bit Field
     */
    public short getCheckpoints() {
        if (checkpoints == -1) {
            computeCheckpoints();
        }
        return checkpoints;
    }


    public byte get(int x, int y) {
        return map[y][x];
    }

    public byte get(Position p) {
        return map[p.y][p.x];
    }

    protected void set(int x, int y, byte karocode) {
        map[y][x] = karocode;
       notifyChanged();
    }


    @Override
    public boolean equals(Object o) {
        if (o instanceof KaroBaseMap r) {

            for (int i = 0; i < getHeight(); i++) {
                int w = getWidth();
                for (int j = 0; j < w; j++) {
                    if (map[i][j] != r.map[i][j]) {
                        return false;
                    }
                }
            }
            return true;
        }
        return false;
    }


    @Override
    public int hashCode() {
        int hashCode = 0;
        int shift = 0;

        for (int i = getHeight() - 1; i >= 0; i--) {
            for (int j = getWidth() - 1; j >= 0; j--) {
               hashCode ^= Integer.rotateLeft(get(j, i), shift++);
            }
        }
        return hashCode;
    }

    public boolean isDriveable(int x, int y) {
        return KaroMapConstants.isDriveable(get(x, y));
    }

}
