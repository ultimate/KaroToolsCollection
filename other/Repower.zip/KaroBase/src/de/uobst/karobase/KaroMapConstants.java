/*
 * Created on Apr 9, 2004
 *
 */
package de.uobst.karobase;

import java.util.stream.IntStream;

/**
 * @author ulli
 */
public abstract class KaroMapConstants {

    public static final byte ASPHALT = 100;
    public static final byte RASEN = 101;
    public static final byte ZIEL = 102;
    public static final byte START = 103;
    public static final byte CLOSED = 104;
    public static final byte MATSCH1 = 1;
    public static final byte MATSCH2 = 2;
    public static final byte PARC_FERME = 3;
    public static final byte WASSER = 4;
    public static final byte SCHNEE = 5;
    public static final byte MOUNTAIN = 6;
    public static final byte GOLD = 7;
    public static final byte LAVA = 8;
    public static final byte TEER = 9;
    public static final byte NACHT = 10;

    // Pseudo Codes
    public static final byte CPX = 105;
    public static final byte VERSION_PREFIX = 'V';

    public static final byte CP_MIN = '0';
    public static final byte CP_MAX = '9';

    private static final boolean[] DRIVEOVER_MAP = new boolean[128];
    static {
        DRIVEOVER_MAP[ASPHALT] = true;
        DRIVEOVER_MAP[START] = true;
        DRIVEOVER_MAP[ZIEL] = true;
        IntStream.rangeClosed(CP_MIN + 1,CP_MAX).forEach(b -> DRIVEOVER_MAP[b] = true);
    }


    public static boolean isCP(byte b) {
        return b >= CP_MIN && b <= CP_MAX;
    }
    public static int getCPBit(byte cpKarocode) {
        return isCP(cpKarocode) ? (1 << karocodeToCpIndex(cpKarocode)): 0;
    }

    public static byte cpIndexToKarocode(int idx) {
        return (byte)(idx + CP_MIN);
    }

    public static boolean isDriveable(byte karocode) {
        return DRIVEOVER_MAP[karocode];
    }

    public static int karocodeToCpIndex(byte karocode) {
        return karocode - CP_MIN;
    }

    public static int getBitCount(int v) {
        int count = 0;
        for (int i = 0; i < 32; i++) {
            if ((v & (1 << i)) != 0) {
                count++;
            }
        }
        return count;
    }

    public static String getCheckpointString(int checkpoints) {
        StringBuffer sb = new StringBuffer();
        for (int i = 9; i >= 1; i--) {
            if ((checkpoints & (1 << i)) != 0) {
                sb.append(i);
            }
        }
        return sb.toString();
    }


}
