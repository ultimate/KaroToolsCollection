/*
 * Created on Apr 9, 2004
 *
 */
package de.uobst.karobase;

import java.io.Serializable;
import java.util.Collection;

/**
 * @author ulli
 */
public final class Position implements Serializable {
    static final long serialVersionUID = 1710068820926721019L;

    public int x;
    public int y;

    public Position(Position p) {
        this.x = p.x;
        this.y = p.y;
    }

    public Position() {
        x = 0;
        y = 0;
    }

    public Position(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() {
        return "x: " + x + ", y: " + y;
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof Position p
            && p.x == this.x && p.y == this.y;
    }

    public int compare(Position p) {
        if (this.x < p.x) {
            return -1;
        } else if (this.x > p.x) {
            return 1;
        } else if (this.y < p.y) {
            return -1;
        } else if (this.y > p.y) {
            return 1;
        } else {
            return 0;
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        return x << 16 + y;
    }

    public double distance(Position other) {
        return Math.sqrt((this.x - other.x) * (this.x - other.x) + (this.y - other.y) * (this.y - other.y));
    }

    public static Position center(Collection<? extends Position> positions) {
        return new Position(Math.round(positions.stream().mapToInt(p -> p.x).sum() / (float)positions.size()),
            Math.round(positions.stream().mapToInt(p -> p.y).sum() / (float)positions.size()));
    }
}
