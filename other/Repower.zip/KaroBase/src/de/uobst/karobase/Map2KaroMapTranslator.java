/*
 * Created on Nov 14, 2005
 *
 */
package de.uobst.karobase;

import static de.uobst.karobase.KaroMapConstants.ASPHALT;
import static de.uobst.karobase.KaroMapConstants.GOLD;
import static de.uobst.karobase.KaroMapConstants.LAVA;
import static de.uobst.karobase.KaroMapConstants.MATSCH1;
import static de.uobst.karobase.KaroMapConstants.MATSCH2;
import static de.uobst.karobase.KaroMapConstants.MOUNTAIN;
import static de.uobst.karobase.KaroMapConstants.NACHT;
import static de.uobst.karobase.KaroMapConstants.PARC_FERME;
import static de.uobst.karobase.KaroMapConstants.RASEN;
import static de.uobst.karobase.KaroMapConstants.SCHNEE;
import static de.uobst.karobase.KaroMapConstants.START;
import static de.uobst.karobase.KaroMapConstants.TEER;
import static de.uobst.karobase.KaroMapConstants.WASSER;
import static de.uobst.karobase.KaroMapConstants.ZIEL;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/** This class transforms Didis map pepresentation in internal codes and vice versa.
 * @author ulli
 */
public class Map2KaroMapTranslator {
    public static final Charset ENCODING = StandardCharsets.ISO_8859_1;

    /** Translation of didi code to internal code, e.g. translation['O'] yields ASPHALT
     */
    private static byte[] translation = new byte[127];

    /** Translation of internal code to Didi code e.g. reverse_translation[ASPHALT] yields 'O'
     */
    private static char[] reverse_translation = new char[127];

    static {
        Arrays.fill(translation, RASEN);
        Arrays.fill(reverse_translation, 'X');
        translation['P'] = PARC_FERME;
        translation['Z'] = MATSCH1;
        translation['Y'] = MATSCH2;
        translation['N'] = SCHNEE;
        translation['W'] = WASSER;
        translation['V'] = MOUNTAIN;
        translation['G'] = GOLD;
        translation['L'] = LAVA;
        translation['O'] = ASPHALT;
        translation['S'] = START;
        translation['F'] = ZIEL;
        translation['T'] = TEER;
        translation['.'] = NACHT;

        for (char c = '1'; c <= '9'; c++) {
            translation[c] = (byte)c;
        }

        // Fill reverse translation table
        for (char i = 0; i < 127; i++) {
            if (translation[i] != RASEN) {
                reverse_translation[translation[i]] = i;
            }
        }
    }

    /** Translates a Didi code to internal code
     *
     * @param c Didis code
     * @return internal code. Unknown codes are translated to {@link KaroMapConstants#RASEN}
     */
    public static byte translateToInternal(char c) {
        return translation[c];
    }

    /** Translates a local code to Didis Kaco Character
     * Unknown codes are translated to 'X' (RASEN)
     * @param b Internbal code
     * @return Didi code
     */
    public static char translateToDidiCode(byte b) {
        return reverse_translation[b];
    }


    public static boolean isValidDidiCode(char code) {
        return code == 'X' || (code >= 0 && code < translation.length && translation[code] != RASEN);
    }

    public static String getAllKnownDidiCodes() {
        return IntStream.range(0,  translation.length)
            .filter(i -> translation[i] != RASEN)
            .mapToObj(i -> String.valueOf((char)i))
            .collect(Collectors.joining()) + 'X';
    }

    public String  exportToDidiCode(KaroBaseMap map) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < map.getHeight(); i++) {
            for (int j = 0; j < map.getWidth(); j++) {
                sb.append(translateToDidiCode(map.get(j, i)));
            }
            sb.append('\n');
        }
        return sb.toString();
    }


    public byte[][] translate2Internal(String didiCodeMap) {
        List<byte[]> karoMap = new ArrayList<byte[]>();

        try (BufferedReader reader = new BufferedReader(new StringReader(didiCodeMap))) {
            String line;

            while ((line = reader.readLine()) != null) {
                int n = line.length();
                int n0;

                // Handle maps with dfferent linelengths
                if (karoMap.size() > 0) {
                    n0 = karoMap.get(0).length;
                    if (n > n0) {
                        n = n0;
                    }
                } else {
                    n0 = n;
                }

                byte[] bline = new byte[n0];
                Arrays.fill(bline, RASEN);

                for (int i = 0; i < n; i++) {
                    char c = line.charAt(i);
                    if (isValidDidiCode(c)) {
                        bline[i] = translateToInternal(c);
                    }

                }
                karoMap.add(bline);
            }
            return karoMap.toArray(new byte[][]{});
        } catch (IOException ex) {
            // Can't happen since reading from a string
            throw new RuntimeException(ex);
        }
    }
}
